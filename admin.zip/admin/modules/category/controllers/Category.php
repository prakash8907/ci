<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Category extends MX_Controller {
	public function __construct()
	{
	    parent :: __construct();
		$this->load->library('form_validation');
		$this->load->model('Category_model','category');   
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{
	    $this->chk_login();
		$data = array();
		$theme = $this->session->userdata('admin_theme');
		$id = $this->session->userdata('user_id');
	    $data['admin'] = $this->category->getAdmin($id,'users');
	    $data['category'] = $this->category->getAll();
        if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/category/index.php'))
		{
			$this->load->view('themes/'.$theme.'/template/category/index',$data);
		}
		else
		{
			$this->load->view('themes/WHITE-COAT/template/category/index',$data);
		}
	}
	
	public function add()
	{
		$data = array();
		$theme = $this->session->userdata('admin_theme');
		$id = $this->session->userdata('user_id');
	    $data['admin'] = $this->category->getAdmin($id,'users');
        if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/category/add.php'))
		{
			$this->load->view('themes/'.$theme.'/template/category/add',$data);
		}
		else
		{
			$this->load->view('themes/WHITE-COAT/template/category/add',$data);
		}
	}
	
	public function insert()
	{
	    $this->form_validation->set_rules('title','Title','required');
	    if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('category/add');
        }
        else
        {
            $data = array(
                'Name' => ucwords(post('title')),
                'Description' => post('desc')
            );
            $this->category->insert($data);
            $this->session->set_flashdata('success', 'Blogs Category Added Successfully.');
            redirect('category');
        }
	}
	
	public function edit($catid)
	{
		$data = array();
		$id = $this->session->userdata('user_id');
	    $data['admin'] = $this->category->getAdmin($id,'users');
	    $data['category'] = $this->category->getSingle($catid);
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/category/edit.php'))
		{
			$this->load->view('themes/'.$theme.'/template/category/edit',$data);
		}
		else
		{
			$this->load->view('themes/WHITE-COAT/template/category/edit',$data);
		}
	}
	
	
	public function update()
	{
	    $this->form_validation->set_rules('title','Title','required');
	    if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('category/edit/'.post('id'));
        }
        else
        { 
            $id = post('id'); 
            $data = array(
                'Name' => ucwords(post('title')),
                'Description' => post('desc'),
                'ModifiedBy' => $this->session->userdata('user_id'),
                'ModifiedOn' => date('Y-m-d h:i:s')
            );
            
            $this->category->update($id,$data);
            $this->session->set_flashdata('success', 'Blogs Category Update Successfully.');
            redirect('category');
        }
	}
	
	public function delete($catid)
	{
	    $data = array();
	    $data['Deleted'] = '1';
		$query = $this->category->delete($catid,$data);
		$this->session->set_flashdata('success','Blogs Category delete Successfully');
		redirect('category');
	}
}