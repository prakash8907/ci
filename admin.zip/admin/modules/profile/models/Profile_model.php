<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Profile_model extends CI_model
{
    const TABLE_NAME = 'users';
    const PRI_INDEX = 'id';
    
    public function getUser($id)
    {
        $this->db->where(self::PRI_INDEX,$id);
        return $this->db->get(self::TABLE_NAME)->row();
    }
    
    public function update($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
        $this->db->update(self::TABLE_NAME,$data);
        return $this->db->affected_rows();
    }
}	