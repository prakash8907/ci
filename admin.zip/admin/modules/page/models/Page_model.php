<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Page_model extends CI_model
{
    const TABLE_NAME = 'tbl_page_content';
    const PRI_INDEX = 'Id';
    
    public function getAdmin($id,$table)
    {
        $this->db->where('id',$id);
        return $this->db->get($table)->row();
    }
    
    public function getAll()
    {
        $this->db->where('Deleted','0');
    	return $this->db->get(self::TABLE_NAME)->result_array();
    }
    
    
    public function getData($id)
    {
    	$this->db->where(self::PRI_INDEX,$id);
    	return $this->db->get(self::TABLE_NAME)->row();
    }

    
    public function update($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
    	$this->db->update(self::TABLE_NAME,$data);
    	return $this->db->affected_rows();
    }
    
    public function delete($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
        $this->db->update(self::TABLE_NAME, $data);
    }
}	