<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Blogs  
  <a href="<?php echo base_url('blog/add'); ?>" class="label label-info">ADD NEW</a>
  </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Blogs</li>
  	</ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
             <?php echo Modules::run('messages/message/index'); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Available Blogs</h3>
                </div>
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SR#</th>
                                <th>Blogs </th>
                                <th>Featured </th>
                                <th>Category </th>
                                <th>Description </th>
                                <th>Cover Image </th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $i='1';
                            foreach($blog as $bl) :
                                $cover = getuploadpath().'upload/blog/'.$bl['Cover'];
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td> 
                                <td><?php echo substr($bl['Name'],0,50); ?></td> 
                                <td><?php echo ($bl['Featured']=="1")?'Featured Blog':'-'; ?></td>
                                <td><?php echo $bl['CatName'];?></td>
                                <td><?=substr($bl['Description'],0,100) ?></td> 
                                <td>
                                    <img src="<?php echo $cover; ?>" class="img-responsive" style="width:50px">
                                </td>
                                <td>
                                    <div class="btn-group-horizontal">
                      					<a href="<?php echo base_url('blog/edit/').$bl['BlogId']; ?>" class="label label-warning editcont" >EDIT</a>
                      					<a href="<?php echo base_url('blog/delete/').$bl['BlogId']; ?>" class="label label-danger editcont" >DELETE</a>
                    				</div>
                                </td> 
                            </tr>
                            <?php $i++; endforeach;  ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>SR#</th>
                                <th>Blogs </th>
                                <th>Featured </th>
                                <th>Category </th>
                                <th>Description </th>
                                <th>Cover Image </th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo Modules::run('Footer/Footer/index');?>
