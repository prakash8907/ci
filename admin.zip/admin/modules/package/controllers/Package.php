<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Package extends MX_Controller {
	public function __construct()
	{
	    parent :: __construct();
		$this->load->library('form_validation');
		$this->load->model('Package_model','package');   
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{
	    $this->chk_login();
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->package->getAdmin($id,'users');
		$data['package'] = $this->package->getAll();
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/package/index.php'))
		{
			$this->load->view('themes/'.$theme.'/template/package/index',$data);
		}
		else
		{
			$this->load->view('themes/default/template/package/index',$data);
		}
	}
	
	public function add()
	{
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->package->getAdmin($id,'users');
		$theme = $this->session->userdata('admin_theme');
		$data['company'] = $this->package->getAllOther('tbl_company');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/package/add.php'))
		{
			$this->load->view('themes/'.$theme.'/template/package/add',$data);
		}
		else
		{
			$this->load->view('themes/default/template/package/add',$data);
		}
	}
	
	public function insert()
	{
	    $this->form_validation->set_rules('name','Package/Service name','required');
		if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('package/add');
        }
        else
        {
            $upload_path = $this->config->item('upload_path').'/package';
        	if(!file_exists($upload_path))
        	{
        		mkdir($upload_path,0777,true);
        	}
        	$config['upload_path']    =  $upload_path;
            $config['allowed_types']  = 'gif|jpg|png|jpeg|x-png|pdf|doc|docx';
			$this->load->library('upload', $config);
            
            if ($this->upload->do_upload('attachfile')) {
        		$image = $this->upload->data();
        		$data['Cover'] = $image['file_name'];
            } 
            
            $data['Name'] = ucwords(post('name'));
            $data['Company'] = post('company');
            $data['Price'] = post('price');
            $data['Description'] = post('editor1');
            $data['Long_Description'] = post('editor2');
            
            $data['edit'] = post('edit');
            $data['consult'] = post('consult');
            $data['isbundled'] = post('isbundled');
            
            $data['pse'] = post('pse');
            $data['psc'] = post('psc');
            
            $data['ase'] = post('ase');
            $data['asc'] = post('asc');
            
            $data['sse'] = post('sse');
            $data['ssc'] = post('ssc');
            
            $data['mie'] = post('mie');
            $data['mic'] = post('mic');
            
            $data['ge'] = post('ge');
            $data['gc'] = post('gc');
            
            $sql = $this->package->insert($data);
            $this->session->set_flashdata('success','Package/Service Added Successfully.');
            redirect('package');
        }
	}
	
	public function edit($pkgid)
	{
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->package->getAdmin($id,'users');
		$data['package'] = $this->package->getData($pkgid);
		$data['company'] = $this->package->getAllOther('tbl_company');
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/package/edit.php'))
		{
			$this->load->view('themes/'.$theme.'/template/package/edit',$data);
		}
		else
		{
			$this->load->view('themes/default/template/package/edit',$data);
		}
	}
	
	public function update()
	{
	    $this->form_validation->set_rules('name','Package/Service name','required');
		if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('package/edit/'.post('id'));
        }
        else
        {
            $upload_path = $this->config->item('upload_path').'/package';
        	if(!file_exists($upload_path))
        	{
        		mkdir($upload_path,0777,true);
        	}
        	$config['upload_path']    =  $upload_path;
            $config['allowed_types']  = 'gif|jpg|png|jpeg|x-png|pdf|doc|docx';
			$this->load->library('upload', $config);
            if ($this->upload->do_upload('attachfile')) {
        		$image = $this->upload->data();
        		$data['Cover'] = $image['file_name'];
            } else {
                $data['Cover'] = post('oldCover');
            }
            
            $id = post('id');
            $data['Name'] = ucwords(post('name'));
            $data['Company'] = post('company');
            $data['Price'] = post('price');
            $data['Description'] = post('editor1');
            $data['Long_Description'] = post('editor2');
            $data['ModifiedOn'] = date('Y-m-d h:i:s');
            $data['ModifiedBy'] = $this->session->userdata('user_id');
            
            $data['edit'] = post('edit');
            $data['consult'] = post('consult');
            $data['isbundled'] = post('isbundled');
            $data['pse'] = post('pse');
            $data['psc'] = post('psc');
            
            $data['ase'] = post('ase');
            $data['asc'] = post('asc');
            
            $data['sse'] = post('sse');
            $data['ssc'] = post('ssc');
            
            $data['mie'] = post('mie');
            $data['mic'] = post('mic');
            
            $data['ge'] = post('ge');
            $data['gc'] = post('gc');
            
            $sql = $this->package->update($id,$data);
            $this->session->set_flashdata('success','Package/Service Update Successfully.');
            redirect('package');
        }
	}
	
	public function delete($id)
	{
	    $data = array();
	    $data['Deleted'] = '1';
		$query = $this->package->delete($id,$data);
		$this->session->set_flashdata('success','Package/Service delete Successfully');
		redirect('package');
	}
}