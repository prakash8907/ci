<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Web_model extends CI_model
{
    const TABLE_NAME = 'tbl_web';
    const PRI_INDEX = 'id';
    
    public function getAdmin($id,$table)
    {
        $this->db->where(self::PRI_INDEX,$id);
        return $this->db->get($table)->row();
    }
    
    public function getdata()
    {
        $this->db->where(self::PRI_INDEX,'1');
        return $this->db->get(self::TABLE_NAME)->row();
    }
    
    public function update($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
        $this->db->update(self::TABLE_NAME,$data);
        return $this->db->affected_rows();
    }
    
    public function getdatasettings($table)
    {
        $this->db->where('setting_id','5');
        return $this->db->get($table)->row();
    }
}	