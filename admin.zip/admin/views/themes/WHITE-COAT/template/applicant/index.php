<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> New Consultant Request  
  </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('consultant')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">New Consultant Request</li>
  	</ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
             <?php echo Modules::run('messages/message/index'); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">New Request</h3>
                </div>
                <div class="box-body showconsult">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SR#</th>
                                <th>Applicant Name </th>
                                <th>E-Mail</th>
                                <th>Registered From</th>
                                <th>Registered Time</th>
                                <th>Consult</th>
                                <th>View Details</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $i='1';
                            foreach($consultant as $consult) :
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td> 
                                <td><?php echo ucwords($consult['username']);?></td>
                                <td><?php echo $consult['email'];?></td>
                                <td><?php if($consult['Fb_token'] !=""){ echo $consult['Fb_token'] .' - Facebook Registration';} else { echo "WCS Registration";}?></td>
                                <td><?php echo date('M d, Y',strtotime($consult['created']));?></td>
                                <td>
                                    <div class="popup" onclick="myFunction(<?=$consult['id']?>)"> <span class="label label-warning">Consultant</span>
                                        <span class="popuptext" id="myPopup_<?=$consult['id']?>">
                                            <?php $allconsult = $this->db->query("SELECT * FROM tbl_meeting WHERE Status = '0' AND Client =".$consult['id'])->result_array();
                                                foreach($allconsult as $cns):
                                                    $cId = $cns['Consultant'];
                                                    $cname = $this->db->query("SELECT * FROM tbl_register WHERE id =".$cId)->row();  
                                                    if($cname){
                                                        echo $cname->username.'<br>';
                                                    } else {
                                                        echo "No Consultant.";
                                                    }
                                                    endforeach;
                                            ?>
                                        </span>
                                    </div>
                          <!--          <div class="btn-group-horizontal_<?=$consult['id']?>">-->
                          <!--      	    <a href="javascript:void(0)" data-id="<?=$consult['id']?>" data-toggle="modal" data-target="#consultModel"class="label label-warning viewConsult" > Consultant</a>-->
                      				<!--</div>-->
                                </td>
                                <td>
                                    <div class="btn-group-horizontal_<?=$consult['id']?>">
                                	    <a href="javascript:void(0)" data-id="<?=$consult['id']?>" data-toggle="modal" data-target=".bd-example-modal-lg" class="label label-info viewdetail" >View Details</a>
                      				</div>
                                </td> 
                                <td>
                                    <div class="btn-group-horizontal_<?=$consult['id']?>">
                                        <?php if($consult['activated'] == "0"){?>
                      					    <a href="javascript:void(0)" data-id="<?=$consult['id']?>" class="label label-warning editcont activateconsult" >Not Activated</a>
                      					<?php } else { ?>
                      					    <a href="<?=base_url('applicant/assign/').$consult['id']?>" class="label label-info viewpackage">Edit</a>
                      					    <a href="javascript:void(0)" class="label label-success editcont" >Activated</a>
                      					    <a href="<?php echo base_url('applicant/delete/').$consult['id']; ?>" class="label label-danger editcont" >DELETE</a>
                      					<?php } ?>
                    				</div>
                                </td> 
                            </tr>
                            <?php $i++; endforeach;  ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>SR#</th>
                                <th>Applicant Name </th>
                                <th>E-Mail</th>
                                <th>Registered From</th>
                                <th>Registered Time</th>
                                <th>Consult</th>
                                <th>View Details</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!---->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <section class="consultant_banner">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                
                        </div>
                    </div>
                </div>
            </section>
            
            <section class="natus_sec">
                
            </section>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!---->
<div class="modal fade" id="consultModel" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!---->
<?php echo Modules::run('Footer/Footer/index');?>
<script>
$('.activateconsult').click(function(e){  
    e.preventDefault();
    url = $(this).attr('href');
    id = $(this).data('id');  
    swal({
        title: "Are you sure to activate consultant ?",
        text: "activate",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, activate it!",
        cancelButtonText: "No",
    }, function(isConfirm){
    
        if (isConfirm) {
            $.ajax({
                type:'POST',
                url:url,
                success:function(data)
                { 
                    $('.btn-group-horizontal_'+id).html('<a href="javascript:void(0)" class="label label-success editcont" >Activated</a>')
                }
            });
      	} 
    });
});
$('.viewdetail').click(function(){
    var id = $(this).data('id');     
    $.ajax({
        type:'POST',
        url:'<?=base_url('applicant/getclient')?>',
        data:{'client_id':id},
        success:function(response)
        {  
            $('.natus_sec').html(response);
        }
    });
});

function myFunction(id) {
    $('.popuptext').removeClass('show');
    var popup = document.getElementById("myPopup_"+id);
    popup.classList.toggle("show");
}
</script>
 