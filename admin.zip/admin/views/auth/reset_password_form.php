<?php
$new_password = array(
	'name'	=> 'new_password',
	'id'	=> 'new_password',
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
	'placeholder'=>'Password',
	'class'=>'form-control'
);
$confirm_new_password = array(
	'name'	=> 'confirm_new_password',
	'id'	=> 'confirm_new_password',
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size' 	=> 30,
	'placeholder'=>'Confirm-Password',
	'class'=>'form-control'
);
$submit = array(
    'class' => 'btn btn-primary btn-block btn-flat'
);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>White Coat Strategists</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/ionicons.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/blue.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/custom.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/jquery.password.css">

    <style>
        .error {
            font-size: 12px;
            letter-spacing: 0px;
            text-transform: uppercase; }
    </style>
    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <?php if($web->weblogo !="") {?>
                <a href="javascript:void(0)"><img src="<?=getuploadpath().'upload/web/'.$web->weblogo?>"></a>
            <?php } else { ?>
                <a href="javascript:void(0)"><b>WHITE COAT</b> STRATEGISTS</a>
            <?php } ?>
        </div>
        <div class="login-box-body">
            <p class="login-box-msg">NEW PASSWORD ADMINISTRATION</p>
            <?php echo form_open($this->uri->uri_string()); ?>
            <div class="form-group has-feedback">
                <?php echo form_password($new_password); ?>
                <span class="fa fa-unlock-alt form-control-feedback"></span>
                <span class="error"><?php echo form_error($new_password['name']); ?><?php echo isset($errors[$new_password['name']])?$errors[$new_password['name']]:''; ?></span>
            </div>
            <div class="form-group has-feedback">
                <div id="strongy"></div>    
            </div>
            <div class="form-group has-feedback">
                <?php echo form_password($confirm_new_password); ?>
                <span class="fa fa-unlock-alt form-control-feedback"></span>
                <span class="error"><?php echo form_error($confirm_new_password['name']); ?><?php echo isset($errors[$confirm_new_password['name']])?$errors[$confirm_new_password['name']]:''; ?></span>
            </div>
            <div class="form-group has-feedback">
                <?php echo form_submit('change', 'Change Password',$submit); ?>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/bootstrap.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/icheck.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.validate.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.password.js"></script>
    <script>
    $(function() {
		$('#new_password').password({
			minLength:6,
			strengthIndicator:$('#strongy'),
		});
	});
    </script>    
</body>
</html>
 