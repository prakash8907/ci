<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Blog_model extends CI_model
{
    const TABLE_NAME = 'tbl_blog';
    const PRI_INDEX = 'BlogId';
    
    public function getAdmin($id,$table)
    {
        $this->db->where('id',$id);
        return $this->db->get($table)->row();
    }
    
    public function getAllcategory($table)
    {
        $this->db->where('Deleted','0');
        return $this->db->get($table)->result_array();
    }
    
    public function getData($id)
    {
    	$this->db->where(self::PRI_INDEX,$id);
    	return $this->db->get(self::TABLE_NAME)->row();
    }

    public function insert($data)
    {
        if(!empty($data)){
            $this->db->insert(self::TABLE_NAME,$data);
            return $this->db->insert_id();
        }
    }
    
    public function getAll()
    {
        $this->db->where('tbl_blog.Deleted','0');
        $this->db->select('tbl_blog.*,tbl_category.Name as CatName', FALSE);
        $this->db->join('tbl_category', 'tbl_category.CatId = tbl_blog.Category');
        $this->db->order_by('tbl_blog.BlogId','DESC');
        return $this->db->get(self::TABLE_NAME)->result_array();
    }
    
    public function update($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
    	$this->db->update(self::TABLE_NAME,$data);
    	return $this->db->affected_rows();
    }
    
    public function delete($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
        $this->db->update(self::TABLE_NAME, $data);
    }
    
    
}	