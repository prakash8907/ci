<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Payment_model extends CI_model
{
    const TABLE_NAME = 'tbl_blog';
    const PRI_INDEX = 'BlogId';
    
    public function getAdmin($id,$table)
    {
        $this->db->where('id',$id);
        return $this->db->get($table)->row();
    }
    
    public function getpayment()
    {
    	$this->db->where('tbl_plan_payment.Deleted','0');
    	$this->db->where('tbl_plan_payment.Pack_status','0');
        $this->db->select('tbl_plan_payment.*,tbl_register.*,tbl_package.*', FALSE);
        $this->db->join('tbl_register', 'tbl_plan_payment.Customer = tbl_register.id');
        $this->db->join('tbl_package', 'tbl_package.PkgId = tbl_plan_payment.Package');
        $this->db->order_by('tbl_plan_payment.id','DESC');
        return $this->db->get('tbl_plan_payment')->result_array();
    }

}	