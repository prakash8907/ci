<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Applicant_model extends CI_model
{
    const TABLE_NAME = 'tbl_web';
    const PRI_INDEX = 'id';
    const TABLE_USER = 'tbl_register';
    
    public function getAdmin($id,$table)
    {
        $this->db->where(self::PRI_INDEX,$id);
        return $this->db->get($table)->row();
    }
     
    public function getClient()
    {
        $this->db->order_by('id','DESC');
        $this->db->where('type','Client');
        return $this->db->get(self::TABLE_USER)->result_array();
    }
    
    public function getClientSingle($id)
    {
        $this->db->where('id',$id);
        return $this->db->get(self::TABLE_USER)->row();
    }
    
    public function delete($id)
    {
        $this->db->where('id',$id);
        $this->db->delete(self::TABLE_USER);
    }
    
    public function packdetail($id)
    {
        $this->db->where('tbl_plan_payment.Customer',$id); 
        $this->db->where('tbl_plan_payment.Deleted','0'); 
        $this->db->where('tbl_plan_payment.Pack_status','0');
        $this->db->select('tbl_plan_payment.*,tbl_package.*',FALSE );
        $this->db->join('tbl_package', 'tbl_package.PkgId = tbl_plan_payment.Package');
        return $this->db->get('tbl_plan_payment')->result_array();
    }
    
    public function countdetails($id,$pack)
    {
        $this->db->where('Customer',$id);
        $this->db->where('Package',$pack);
        $this->db->where('Deleted','0');
        $this->db->where('Pack_status','0');
        return $this->db->get('tbl_plan_payment')->row();
    }
    
    public function assigncount($id,$pack,$data)
    {
        $this->db->where('Customer',$id);
        $this->db->where('Deleted','0');
        $this->db->where('Package',$pack);
        $this->db->update('tbl_plan_payment',$data);
        return $this->db->affected_rows();
    }
}	