<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Package/Service
  <a href="<?php echo base_url('package/add'); ?>" class="label label-info">ADD NEW</a>
  </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Package/Service</li>
  	</ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
             <?php echo Modules::run('messages/message/index'); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Available Package/Service</h3>
                </div>
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SR#</th>
                                <th>Package </th>
                                <th>Price </th>
                                <th>Company </th>
                                <th>Description </th>
                                <th>Cover Image </th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $i='1';
                            foreach($package as $pkg) :
                                $cover = getuploadpath().'upload/package/'.$pkg['Cover'];
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td> 
                                <td><?php echo $pkg['Name']; ?></td> 
                                <td><?php echo '$'.$pkg['Price']; ?></td>
                                <td><?php echo $pkg['Companyname'];?></td>
                                <td><?=substr($pkg['Description'],0,100) ?></td> 
                                <td>
                                    <img src="<?php echo $cover; ?>" class="img-responsive" style="width:50px">
                                </td>
                                <td>
                                    <div class="btn-group-horizontal">
                      					<a href="<?php echo base_url('package/edit/').$pkg['PkgId']; ?>" class="label label-warning editcont" >EDIT</a>
                      					<a href="<?php echo base_url('package/delete/').$pkg['PkgId']; ?>" class="label label-danger editcont" >DELETE</a>
                    				</div>
                                </td> 
                            </tr>
                            <?php $i++; endforeach;  ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>SR#</th>
                                <th>Package </th>
                                <th>Price </th>
                                <th>Company </th>
                                <th>Description </th>
                                <th>Cover Image </th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo Modules::run('Footer/Footer/index');?>
