<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Blogs Category 
  <a href="<?php echo base_url('category/add'); ?>" class="label label-info" >ADD NEW</a>
  </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Blogs Category</li>
  	</ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
             <?php echo Modules::run('messages/message/index'); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Available Blogs Category</h3>
                </div>
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SR#</th>
                                <th>Category Name</th>
                                <th>Category Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $i='1';
                            foreach($category as $cat) :
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td> 
                                <td><?php echo $cat['Name']; ?></td> 
                                <td><?= ($cat['Description']!="")?substr($cat['Description'],0,100):"-"; ?></td> 
                                <td>
                                    <div class="btn-group-horizontal">
                      					<a href="<?php echo base_url('category/edit/').$cat['CatId']; ?>" class="label label-warning editcont" >EDIT</a>
                      					<a href="<?php echo base_url('category/delete/').$cat['CatId']; ?>" class="label label-danger editcont">DELETE</a>
                    				</div>
                                </td> 
                            </tr>
                            <?php $i++; endforeach;  ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>SR#</th>
                                <th>Category Name</th>
                                <th>Category Description</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo Modules::run('Footer/Footer/index');?>
