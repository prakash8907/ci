<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends MX_Controller {
	public function __construct()
	{
	    parent :: __construct();
		$this->load->library('form_validation');
		$this->load->model('Dashboard_model','dashboard');   
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{
	    $this->chk_login();
		$data = array();
		$theme = $this->session->userdata('admin_theme');
		$id = $this->session->userdata('user_id');
	    $data['admin'] = $this->dashboard->getAdmin($id);
        if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/dashboard/index.php'))
		{
			$this->load->view('themes/'.$theme.'/template/dashboard/index',$data);
		}
		else
		{
			$this->load->view('themes/WHITE-COAT/template/dashboard/index',$data);
		}
	}
	
	public function password()
	{
		$data = array();
		$id = $this->session->userdata('user_id');
		$theme = $this->session->userdata('admin_theme');
		$data['admin'] = $this->dashboard->getAdmin($id);
        if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/dashboard/password.php'))
		{
			$this->load->view('themes/'.$theme.'/template/dashboard/password',$data);
		}
		else
		{
			$this->load->view('themes/WHITE-COAT/template/dashboard/password',$data);
		}
	}
}