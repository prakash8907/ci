<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Blogs </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('blog')?>">Blogs </a></li>
        <li class="active">Add</li>
  	</ol>
</section>
<section class="content">
  	<div class="row">
     	<div class="col-xs-12">
     	    <?php echo Modules::run('messages/message/index'); ?>
          	 <div class="box box-primary">
	            <div class="box-header with-border">
	              <h3 class="box-title">Add New Blogs</h3>
	            </div>
                <?php 
                echo form_open_multipart('blog/insert',array('class'=>'blog-form','id'=>'blog-form'));
                ?>
             	<div class="box-body">
             	    <div class="row">
             	        <div class="col-md-6">
         	                <div class="form-group">
                          		<label for="exampleInputEmail1">Blog Category</label>
                          		<select class="form-control" id="category" name="category" >
                          		    <option value="">-- Select Blog Category --</option>
                          		    <?php foreach($category as $cat):?>
                          		        <option value="<?php echo $cat['CatId']?>"><?php echo $cat['Name']?></option>
                          		    <?php endforeach; ?>
                          		</select>
                    		</div>
             	        </div>
             	        <div class="col-md-6">
             	            <div class="form-group">
                          		<label for="exampleInputEmail1">Blog Author</label>
                          		<input type="text" class="form-control" id="aname" name="aname" placeholder="Enter Author Name">
                          	</div>
             	        </div>
             	    </div>
             	    
            		
                	
            		<div class="form-group">
                  		<label for="exampleInputEmail1">Blog Name</label>
                  		<input type="text" class="form-control" id="name" name="name" placeholder="Enter Blog Name">
                  	</div>
            		 
                	<div class="form-group">
                  		<label for="exampleInputPassword1">Blog Description</label>
      		            <textarea class="textarea" id="editor1" name="editor1" placeholder="About US Content" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                	</div>
                	
                	<div class="form-group">
                  		<label for="exampleInputEmail1">Blog Timeline</label>
                  		<input type="text" class="form-control" id="timeline" name="timeline" placeholder="Enter Blog Timeline">
                  	</div>
                  	
                  	<div class="form-group">
                  		<label for="exampleInputEmail1">Blog Timeline Author</label>
                  		<input type="text" class="form-control" id="taname" name="taname" placeholder="Enter Blog Timeline Author">
                  	</div>
                  	
                  	<div class="form-group">
                        <label for="exampleInputEmail1">Featured Blog</label><br>
                        <div class="toggle">
                            <input type="hidden" name="feature" id="feature" value="0">
                    	    <input type="checkbox" id="checkbox"/>
                    	    <span class="btn"></span>
                    	    <span class="labels"></span>
                    	    <span class="bg"></span>
                    	</div>
                    </div>
              	</div>
              	
              	 
              	 
              	<div class="box-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputPassword1">Blog Image</label>
                        		<div class="input-group input-file attachfile" name="attachfile">
                        			<span class="input-group-btn">
                                		<button class="btn btn-default btn-choose" type="button">Choose</button>
                            		</span>
                            		<input type="text" class="form-control" placeholder='Choose a file...' />
                            		<span class="input-group-btn">
                               			 <button class="btn btn-warning btn-reset" type="button">Reset</button>
                            		</span>
                        		</div>
        	                </div>
                        </div>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <span id="previewImg"></span>
                        </div>
                    </div>
                </div>
                
              	<div class="box-footer">
                	<button type="submit" class="btn btn-primary">Add Blogs</button>
              	</div>
                <?php echo form_close(); ?>
          	</div>
      	</div>
  	</div>
</section>	
<?php echo Modules::run('Footer/Footer/index');?>
<script>
function bs_input_file() {
	$(".input-file").before(
		function() {
			if ( ! $(this).prev().hasClass('input-ghost') ) {
				var element = $("<input type='file' name='attachfile' class='input-ghost attachfile' style='visibility:hidden; height:0'>");
				element.attr("name",$(this).attr("name"));
				element.change(function(){
					element.next(element).find('input').val((element.val()).split('\\').pop());
				});
				$(this).find("button.btn-choose").click(function(){
					element.click();
				});
				$(this).find("button.btn-reset").click(function(){
					element.val(null);
					$(this).parents(".input-file").find('input').val('');
					$('#previewImg').html('');
				});
				$(this).find('input').css("cursor","pointer");
				$(this).find('input').mousedown(function() {
					$(this).parents('.input-file').prev().click();
					return false;
				});
				return element;
			}
		}
	);
}
$(function() {
	bs_input_file();
});
</script>
<script type="text/javascript">
$(document).ready(function(){
    $(".attachfile").change(function(){  
        readURL(this);  
    });
});

function readURL(input) {
if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(input.files[0]);
    reader.onload = function (e) {  
        $("#previewImg").html("<img class='img-thumbnail' src='" + e.target.result +"' width='200px'>");
      }
       reader.readAsDataURL(input.files[0]);
    }
}
$(document).ready(function(){
    $('#blog-form').validate({
        rules:{
            category:{ required:true },
            name:{ required:true },
            aname:{ required:true },
            attachfile:{ required:true }
        },
        messages:{
            category:{ required:'PLEASE SELECT BLOG CATEGORY.' },
            name:{ required:'PLEASE ENTER BLOG NAME.' },
            aname:{ required:'PLEASE ENTER AUTHOR NAME.' },
            attachfile:{ required:'PLEASE SELECT BLOG COVER IMAGE.' }
        }
    });
});

$('.toggle #checkbox').on('click',function(){
    if($(this).hasClass('on')) {
        $(this).removeClass('on').addClass('off'); 
        $('#feature').val('0');
    } else {
        $(this).removeClass('off').addClass('on');
        $('#feature').val('1');
    }
})
</script>


 