<?php echo Modules::run('Header/Header/index');
if($web->weblogo !=""){
    $logo = getuploadpath().'upload/web/'.$web->weblogo;
} else {
    $logo = base_url('views/themes/WHITE-COAT/assets/').'img/no-image-available.png';
}
if($web->weblogocolor !=""){
    $logocolor = getuploadpath().'upload/web/'.$web->weblogocolor;
} else {
    $logocolor = base_url('views/themes/WHITE-COAT/assets/').'img/no-image-available.png';
}
?>
<section class="content-header">
    <h1>
        <?php echo $web->name; ?> 
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url('dashboard') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Web Setting</li>
    </ol>
</section>
 

<section class="content profiletab">
    <div class="row">
        <div class="col-md-3">
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <span id="previewImg">
                        <img class="profile-user-img img-responsive" src="<?php echo $logo; ?>" alt="admin" style="background:#333333;">
                    </span> 
                    <h3 class="profile-username text-center"><?php echo $web->name; ?> </h3>
                    <p class="text-muted text-center"><?php echo $web->email; ?></p>
                </div>
            </div>
          
             
        </div>
        
        <div class="col-md-9">
            <?php echo Modules::run('messages/message/index'); ?>
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#settings" data-toggle="tab">Settings</a></li>
                </ul>
                
                <div class="tab-content">
                    <div class="tab-pane active" id="settings">
                         
                    <?php 
                        $attribute = array('class'=>'web-form', 'id'=>'web-form');
                        echo form_open_multipart('web/update',$attribute);
                    ?>
                            <div class="row">
                                <div class="col-md-offset-1 col-md-10">
                                    <div class="form-group"> 
                                        <label for="exampleInputEmail1">Organization Name</label>
                                        <input type="hidden" class="form-control" name="webid" value="<?php echo $web->id; ?>">
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter organization name" value="<?php echo $web->name; ?>" autofocus>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-offset-1 col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo $web->email; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Phone Number</label>
                                        <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter phone" value="<?php echo $web->contact; ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-offset-1 col-md-5">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Meta Title</label>
                                        <input type="text" class="form-control" id="title" name="title" placeholder="Enter meta title" value="<?php echo $web->title; ?>">
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Meta Keyword</label>
                                        <input type="text" class="form-control" id="keyword" name="keyword" placeholder="Enter meta keyword" value="<?php echo $web->keyword; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-offset-1 col-md-10">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Meta Description</label>
                                        <textarea class="form-control" placeholder="Enter meta description" name="desc" style="resize:none;height:50px"><?php echo $web->desc; ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-offset-1 col-md-5">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Copyright Content </label>
                                        <textarea rows="5" class="form-control" id="cpy" name="cpy" placeholder="Enter copyright" style="resize:none"><?php echo $web->copyright; ?></textarea>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-offset-1 col-md-5">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Web Logo White</label>
                                        <input type="file" name="weblogo" id="weblogo">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-offset-1 col-md-5">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Web Logo Colored</label>
                                        <input type="file" name="weblogocolor" id="weblogocolor">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-offset-1 col-md-5">
                                    <div class="form-group">
                                        <div id="previewImgcolor"><img src="<?=$logocolor?>" style="width:200px;background:#333333;" class="img-responsive"></imf></div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-offset-1 col-md-10">
                                    <button type="submit" class="btn btn-danger">Update Web Settings</button>
                                </div>
                            </div><br>
                    <?php echo form_close(); ?>  
                    </div>
                    
                </div>
             
            </div>
        </div>
        
    </div>
</section>
 
  
<?php echo Modules::run('Footer/Footer/index');?>

<script>

$(document).ready(function(){
    $('#web-form').validate({
        rules:{
            name:{ required:true },
            email:{ required:true, email:true },
            phone:{ required:true, number:true },
            title:{ required:true },
            keyword:{ required:true },
            desc:{ required:true },
            pin:{ required:true },
        },
        messages:{
            name:{ required:'PLEASE ENTER ORGINIZATION NAME.' },
            email:{ required:'PLEASE ENTER VALID E-MAIL.', email:'PLEASE ENTER VALID E-MAIL.' },
            phone:{ required:'PLEASE ENTER CONTACT.', number:'PLEASE ENTER NUMBERS ONLY.' },
            title:{ required:'PLEASE ENTER META TITLE.' },
            keyword:{ required:'PLEASE ENTER META KEYWORD.' },
            desc:{ required:'PLEASE ENTER META DESCRIPTION.' },
            pin:{ required:'PLEASE ENTER SECURE PIN FOR VERIFY.' }
        }
    });
});
</script>

<script type="text/javascript">
$("#weblogo").change(function(){  
    readURL(this);
});

$("#weblogocolor").change(function(){  
    readURLcolor(this);
});
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.readAsDataURL(input.files[0]);
        reader.onload = function (e) {  
            $("#previewImg").html("<img class='profile-user-img img-responsive' src='" + e.target.result +"' alt='admin'>");
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function readURLcolor(input){
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.readAsDataURL(input.files[0]);
        reader.onload = function (e) {  
            $("#previewImgcolor").html("<img class='img-responsive' src='" + e.target.result +"' alt='admin' width='200px' style='background:#333333'>");
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>