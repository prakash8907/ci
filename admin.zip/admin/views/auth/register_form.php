<?php
if ($use_username) {
	$username = array(
		'name'	=> 'username',
		'id'	=> 'username',
		'value' => set_value('username'),
		'maxlength'	=> $this->config->item('username_max_length', 'tank_auth'),
		'size'	=> 30,
		'placeholder'=>'Username',
	    'class'=>'form-control'
	);
}
$email = array(
	'name'	=> 'email',
	'id'	=> 'email',
	'value'	=> set_value('email'),
	'maxlength'	=> 80,
	'size'	=> 30,
	'placeholder'=>'E-Mail',
    'class'=>'form-control'
);
$password = array(
	'name'	=> 'password',
	'id'	=> 'password',
	'value' => set_value('password'),
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
	'placeholder'=>'Password',
    'class'=>'form-control'
);
$confirm_password = array(
	'name'	=> 'confirm_password',
	'id'	=> 'confirm_password',
	'value' => set_value('confirm_password'),
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
	'placeholder'=>'Confirm-Password',
    'class'=>'form-control'
);
$captcha = array(
	'name'	=> 'captcha',
	'id'	=> 'captcha',
	'maxlength'	=> 8,
	'class'=>'form-control',
	'placeholder'=>'Confirmation Code',
	'style' => 'margin-top:10px',
);

$submit = array(
    'class' => 'btn btn-primary btn-block btn-flat'
);
$captcha_content = '';
if ($captcha_registration) {
	if ($use_recaptcha) {
		$captcha_content = '
		<div id="account-signup-divider" class="shared-divider">
			<div class="shared-divider-label">
				<span>Confirmation Code</span>
			</div>
		</div>

		<div id="recaptcha_image"></div>
		<a href="javascript:Recaptcha.reload()">Get another CAPTCHA</a>
		<div class="recaptcha_only_if_image"><a href="javascript:Recaptcha.switch_type(\'audio\')">Get an audio CAPTCHA</a></div>
		<div class="recaptcha_only_if_audio"><a href="javascript:Recaptcha.switch_type(\'image\')">Get an image CAPTCHA</a></div>

		<div class="recaptcha_only_if_image">Enter the words above</div>
		<div class="recaptcha_only_if_audio">Enter the numbers you hear</div>
		<input type="text" id="recaptcha_response_field form-control" name="recaptcha_response_field" />

		<div id="account-signup-divider" class="shared-divider"></div>
		';

		$captcha_content .= $recaptcha_html;
	} else {
		$captcha_content = '
		 
		<p>Enter the code exactly as it appears:</p>
		'.$captcha_html.'
		<p>'.form_input($captcha).'</p>

		<div id="account-signup-divider" class="shared-divider"></div>
		';
	}
}
?>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Register</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/ionicons.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/blue.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/custom.css">

    <style>
        .form-group img { width:100%;}
        .error {
            font-size: 12px;
            letter-spacing: 0px;
            text-transform: uppercase; }
    </style>
    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <a href="javascript:void(0)"><b>WHITE COAT</b> STRATEGISTS</a>
        </div>
        <div class="login-box-body">
            <p class="login-box-msg">REGISTER NEW ADMINISTRATOR</p>
            <?php echo form_open($this->uri->uri_string()); ?>
            <div class="form-group has-feedback">
                <?php echo form_input($username); ?>
                <span class="fa fa-user form-control-feedback"></span>
                <span class="error"><?php echo form_error($username['name']); ?><?php echo isset($errors[$username['name']])?$errors[$username['name']]:''; ?></span>
            </div>
            <div class="form-group has-feedback">
                <?php echo form_input($email); ?>
                <span class="fa fa-envelope form-control-feedback"></span>
                <span class="error"><?php echo form_error($email['name']); ?><?php echo isset($errors[$email['name']])?$errors[$email['name']]:''; ?></span>
            </div>
            <div class="form-group has-feedback">
                <?php echo form_password($password); ?>
                <span class="fa fa-unlock-alt form-control-feedback"></span>
                <span class="error"><?php echo form_error($password['name']); ?></span>
            </div>
            <div class="form-group has-feedback">
                <?php echo form_password($confirm_password); ?>
                <span class="fa fa-unlock-alt form-control-feedback"></span>
                <span class="error"><?php echo form_error($confirm_password['name']); ?></span>
            </div>
            <div class="form-group has-feedback">
                <?php echo $captcha_content; ?>	 
            </div>
             <div class="row">
                <div class="col-xs-8">
                    <div class="checkbox icheck">
                        <a href="<?php echo base_url('auth/login/') ?>">BACK TO LOGIN ?</a> 
                    </div>
                </div>
            
                <div class="col-xs-4">
                    <?php echo form_submit('register', 'Register',$submit); ?>
                </div>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/bootstrap.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/icheck.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.validate.min.js"></script>
     
</body>
</html>
 