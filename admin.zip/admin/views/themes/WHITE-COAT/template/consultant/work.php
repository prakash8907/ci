<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Consultant Working Hours </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('consultant')?>">Consultant </a></li>
        <li class="active">Working Hours</li>
  	</ol>
</section>
<section class="content">
  	<div class="row">
     	<div class="col-xs-8">
     	    <?php echo Modules::run('messages/message/index'); ?>
          	 <div class="box box-primary">
	            <?php 
                echo form_open('',array('class'=>'work-form','id'=>'work-form'));
                ?>
             	<div class="box-body">
             	    <div class="row">
             	        <div class="col-md-12">
         	                <div class="form-group">
                          		<label for="exampleInputEmail1">Consultant Name</label>
                          		<select class="form-control select2" style="width: 100%;" name="consult" required>
                                    <option value="">Select Consultant</option>
                                    <?php foreach($consultant as $consult):?>
                          		        <option value="<?php echo $consult['id']?>"><?php echo $consult['username']?></option>
                          		    <?php endforeach; ?>
                                </select>
                          	</div>
             	        </div>
             	         
             	    </div>
             	    
            		<div class="row">
            		    <div class="col-md-6">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Work From Date</label>
                          		<div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" name="from" placeholder="YYYY-MM-DD" id="datepickerfrom" required>
                                </div>
                          	</div>
            		    </div>
            		    <div class="col-md-6">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Work To Date</label>
                          		<div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" name="to" placeholder="YYYY-MM-DD" id="datepickerto" required>
                                </div>
                          	</div>
            		    </div>
            		</div>
            		<div class="row showtime">
            		    
            		</div>
                </div>
              	<div class="box-footer">
                	<button type="submit" class="btn btn-primary">Calculate Working Hours</button>
              	</div>
                <?php echo form_close(); ?>
          	</div>
      	</div>
  	</div>
</section>	
<?php echo Modules::run('Footer/Footer/index');?>
<script>

$('#work-form').on('submit',function(e){
    e.preventDefault();
    var data = $('#work-form').serialize();
    $.ajax({ 
        type:'POST',
        url:"<?=base_url('consultant/calculate') ?>",
        data:data,
        success:function(data){ $('.showtime').html(data);}
    });
}); 
</script>