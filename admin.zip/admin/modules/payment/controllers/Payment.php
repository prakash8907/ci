<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Payment extends MX_Controller {
	public function __construct()
	{
	    parent :: __construct();
		$this->load->library('form_validation');
		$this->load->model('Payment_model','payment');   
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{
	    $this->chk_login();
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->payment->getAdmin($id,'users');
		$data['payment'] = $this->payment->getpayment();
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/payment/index.php'))
		{
			$this->load->view('themes/'.$theme.'/template/payment/index',$data);
		}
		else
		{
			$this->load->view('themes/default/template/payment/index',$data);
		}
	}

}