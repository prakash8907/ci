<?php if($this->session->userdata('user_id')==""){ redirect('auth/login/'); } 
if($admin->profile !=""){
    $profile = getuploadpath().'upload/admin/'.$admin->profile;
} else {
    $profile = base_url('views/themes/WHITE-COAT/assets/').'img/default_user.png';
} 
$WEB = $this->db->get('tbl_web')->result_array(); 
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>White Coat Strategists</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/ionicons.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/jquery-jvectormap.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/_all-skins.min.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/sweet-alert.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/custom.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/jquery.password.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/dataTables.bootstrap.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/jasny-bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/select2.min.css">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <header class="main-header">
            <a href="<?php echo base_url('dashboard') ?>" class="logo">
                <span class="logo-mini"><b>W</b>C</span>
                <span class="logo-lg"><b><?php echo $WEB[0]['name']?></b></span>
            </a>

            <nav class="navbar navbar-static-top">
                <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                    <span class="sr-only">Toggle navigation</span>
                </a>
                <!-- Navbar Right Menu -->
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="dropdown user user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="<?php echo $profile; ?>" class="user-image" alt="User Image">
                                <span class="hidden-xs"><?php echo strtoupper($admin->username); ?></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="user-header">
                                    <img src="<?php echo $profile; ?>" class="img-circle" alt="User Image">
                                    <p>
                                    <?php echo strtoupper($admin->username); ?>
                                    <small><?php echo $admin->email; ?></small>
                                    </p>
                                </li>
                                <!-- Menu Body -->
                                <li class="user-footer text-center">
                                    <div class="pull-left">
                                        <a href="<?=base_url('profile') ?>" class="btn btn-block btn-primary btn-flat"><i class="fa fa-user"></i> Profile</a>
                                    </div>
                                    <div class="pull-right">
                                        <a href="<?=base_url('auth/logout') ?>" class="btn btn-block btn-primary btn-flat"><i class="fa fa-sign-out"></i> Sign out</a>
                                    </div>
                                    
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
  
        <!-- Left side column. contains the logo and sidebar -->
        <aside class="main-sidebar">
            <section class="sidebar">
                <div class="user-panel">
                    <div class="pull-left image">
                        <img src="<?php echo $profile; ?>" class="img-circle" alt="User Image">
                    </div>
                    <div class="pull-left info">
                        <p> <i class="fa fa-circle text-success"></i> <?php echo ucwords($admin->username); ?></p>
                        <a href="#"><?php echo $WEB[0]['name']?></a>
                    </div>
                </div>
                <!-- sidebar menu: : style can be found in sidebar.less -->
                <ul class="sidebar-menu" data-widget="tree">
                    <li class="header">MAIN NAVIGATION</li>
                    <!-- Dashboard -->
                    <li class="active treeview menu-open">
                        <a href="#">
                            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="<?php echo base_url('dashboard');?>"><i class="fa fa-tags"></i> Dashboard</a></li>
                        </ul>
                    </li>
                    <!-- Website Settings -->
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-file-text-o"></i>
                            <span>Page Content </span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="<?=base_url('page') ?>"><i class="fa fa-tags"></i> Manage</a></li>
                        </ul>
                    </li>
                    <!-- Company & Service -->
                    <li class="treeview">
                        <a href="#">
                        <i class="fa fa-delicious"></i> <span>Company & Service</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu" style="display: none;">
                            <li class="treeview">
                                <a href="#"><i class="fa fa-minus"></i> Company
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="<?=base_url('company')?>"><i class="fa fa-tags"></i> Manage</a></li>
                                </ul>
                            </li>
                            <li class="treeview">
                                <a href="#"><i class="fa fa-minus"></i> Services/Package
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="<?=base_url('package')?>"><i class="fa fa-tags"></i> Manage</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <!-- Blogs -->
                    <li class="treeview">
                        <a href="#">
                        <i class="fa fa-address-book"></i> <span>Blogs</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu" style="display: none;">
                            <li class="treeview">
                                <a href="#"><i class="fa fa-minus"></i> Blogs Category
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="<?=base_url('category')?>"><i class="fa fa-tags"></i> Manage</a></li>
                                </ul>
                            </li>
                            <li class="treeview">
                                <a href="#"><i class="fa fa-minus"></i> Blogs
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="<?=base_url('blog')?>"><i class="fa fa-tags"></i> Manage</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <!-- Website Settings -->
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-gears"></i>
                            <span>Website Settings </span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="<?=base_url('web') ?>"><i class="fa fa-tags"></i> Manage</a></li>
                        </ul>
                    </li>
                    <!-- Password -->
                    <li>
                        <a href="<?=base_url('dashboard/password') ?>">
                            <i class="fa fa-unlock-alt"></i>
                            <span>Password Changes </span>
                        </a>
                    </li>
                    <!-- Applicant -->
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-user"></i>
                            <span>New Consultant Request </span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="<?=base_url('consultant') ?>"><i class="fa fa-tags"></i> Manage</a></li>
                            <li><a href="<?=base_url('consultant/working') ?>"><i class="fa fa-clock-o"></i> Working Hours</a></li>
                        </ul>
                    </li>
                    
                     
                    <!---->
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-user"></i>
                            <span>Registerd Applicant </span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="<?=base_url('applicant') ?>"><i class="fa fa-tags"></i> Manage</a></li>
                            <li><a href="<?=base_url('payment') ?>"><i class="fa fa-money"></i> Payment Info</a></li>
                        </ul>
                    </li>
                </ul>
            </section>
        </aside>

        <div class="content-wrapper">
            
