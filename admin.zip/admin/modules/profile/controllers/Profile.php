<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Profile extends MX_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->library('form_validation');
		$this->load->model('Profile_model','profile');
	
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{
	    $this->chk_login();
	    $data = array();
	    $id = $this->session->userdata('user_id');
	    $data['admin'] = $this->profile->getUser($id);
	    $theme = $this->session->userdata('admin_theme');
	    if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/profile/index.php'))
	    {
	        $this->load->view('themes/'.$theme. '/template/profile/index',$data);
	    }
	    else
	    {
	        $this->load->view('themes/WHITE-COAT/template/profile/index',$data);
	    }
	}
	
	public function update()
	{
	    $this->form_validation->set_rules('fname','First Name','required');
		if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('profile/').post('adminId');
        }
        else
        {
            $upload_path = $this->config->item('upload_path').'/admin';
            if(!file_exists($upload_path))
        	{  
        		mkdir($upload_path,0777,true);
        	}
            $config['upload_path']    =  $upload_path;
            $config['allowed_types']  = 'gif|jpg|png|jpeg|x-png';
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('profile')) {
        		$image = $this->upload->data();
        		$data['profile'] = $image['file_name'];
            }
            
            $adminId = post('adminId');
             
            $data['email'] = post('email');
            $data['phone'] = post('phone');
            $data['office'] = post('office');   
            $data['edu'] = ucwords(post('education'));
            $data['location'] = ucwords(post('location'));
            $data['bio'] = ucwords(post('bio'));
           
            $sql = $this->profile->update($adminId,$data);
            $this->session->set_flashdata('success','Profile Update Successfully.');
            redirect('profile');
        }
	}
}