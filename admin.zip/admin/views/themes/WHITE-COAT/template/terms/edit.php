<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Terms </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('terms')?>">Terms </a></li>
        <li class="active">Update</li>
  	</ol>
</section>
<section class="content">
  	<div class="row">
     	<div class="col-xs-12">
     	    <?php echo Modules::run('messages/message/index'); ?>
     	    <div class="box box-primary">
	            <div class="box-header with-border">
	              <h3 class="box-title">Update Terms Content</h3>
	            </div>
                <?php 
                echo form_open('terms/update',array('class'=>'terms-form','id'=>'terms-form'));
                ?>
             	<div class="box-body">
                	<div class="form-group">
                  		<label for="exampleInputEmail1">Title</label>
                  		<input type="hidden" class="form-control" name="id" value="<?php echo $terms->Id ?>">
                  		<input type="text" class="form-control" id="title" name="title" placeholder="Enter Title" value="<?php echo $terms->Title ?>">
            		</div>
                	<div class="form-group">
                  		<label for="exampleInputPassword1">Content</label>
      		            <textarea class="textarea" id="editor1" name="editor1" placeholder="About US Content" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $terms->Description ?></textarea>
                	</div>
              	</div>
              
              	<div class="box-footer">
                	<button type="submit" class="btn btn-primary">Update</button>
              	</div>
                <?php echo form_close(); ?>
          	</div>
      	</div>
  	</div>
</section>	
<?php echo Modules::run('Footer/Footer/index');?>
<script>
$(document).ready(function(){
    $('#termsas-form').validate({
        rules:{
            title:{ required:true }
        },
        messages:{
            title:{ required:'PLEASE ENTER TITLE.' }
        }
    });
});
</script>

 