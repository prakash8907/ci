<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Package/Service </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('package')?>">Package/Service </a></li>
        <li class="active">Add</li>
  	</ol>
</section>
<section class="content">
  	<div class="row">
     	<div class="col-xs-12">
     	    <?php echo Modules::run('messages/message/index'); ?>
          	 <div class="box box-primary">
	            <div class="box-header with-border">
	              <h3 class="box-title">Add New Package/Service</h3>
	            </div>
                <?php 
                echo form_open_multipart('package/insert',array('class'=>'package-form','id'=>'package-form'));
                ?>
             	<div class="box-body">
             	    <div class="row">
             	        <div class="col-md-6">
         	                <div class="form-group">
                          		<label for="exampleInputEmail1">Company Name</label>
                          		<select class="form-control" id="company" name="company" >
                          		    <option value="">-- Select Company --</option>
                          		    <?php foreach($company as $cpy):?>
                          		        <option value="<?php echo $cpy['CpyId']?>"><?php echo $cpy['Name']?></option>
                          		    <?php endforeach; ?>
                          		</select>
                    		</div>
             	        </div>
             	         
             	    </div>
             	    
            		<div class="row">
            		    <div class="col-md-6">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Package/Service Name</label>
                          		<input type="text" class="form-control" id="name" name="name" placeholder="Enter Package/Service Name">
                          	</div>
            		    </div>
            		    <div class="col-md-6">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Package/Service Price</label>
                          		<input type="text" class="form-control" id="price" name="price" placeholder="Enter Package/Service Price">
                          	</div>
            		    </div>
            		</div>
                	
            		
                  	
            		 
                	<div class="form-group">
                  		<label for="exampleInputPassword1">Package/Service Short Description</label>
      		            <textarea class="textarea" id="editor1" name="editor1" placeholder="About Package/Service" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                	</div>
                	
                	<div class="form-group">
                  		<label for="exampleInputPassword1">Package/Service Description</label>
      		            <textarea class="textarea" id="editor2" name="editor2" placeholder="About Package/Service" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                	</div>
                	
                	<div class="row bdlcount">
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Edit Count</label>
                          		<input type="text" class="form-control" id="edit" name="edit" placeholder="Enter Edit Count" value="">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Consult Count</label>
                          		<input type="text" class="form-control" id="consult" name="consult" placeholder="Enter Consult Count" value="">
                          	</div>
            		    </div>
        		    </div>
        		    
                	<div class="form-group">
                        <label for="exampleInputEmail1">Bundled Package</label><br>
                        <div class="toggle">
                            <input type="hidden" id="isbundled" name="isbundled" value="0">
                            <input type="checkbox" id="checkbox"/>
                    	    <span class="btn"></span>
                    	    <span class="labels"></span>
                    	    <span class="bg"></span>
                    	</div>
                    </div>
                    
                    <div class="row bundled" style="display:none">
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">PS Service Edit</label>
                          		<input type="text" class="form-control" id="pse" name="pse" placeholder="Enter PS Service Edit">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">PS Service Consult</label>
                          		<input type="text" class="form-control" id="psc" name="psc" placeholder="Enter PS Service Consult">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Activities Service Edit</label>
                          		<input type="text" class="form-control" id="ase" name="ase" placeholder="Enter Activities Service Edit">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Activities Service Consult</label>
                          		<input type="text" class="form-control" id="asc" name="asc" placeholder="Enter Activities Service Consult">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Secondaries Service Edit</label>
                          		<input type="text" class="form-control" id="sse" name="sse" placeholder="Enter Secondaries Service Edit">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Secondaries Service Consult</label>
                          		<input type="text" class="form-control" id="ssc" name="ssc" placeholder="Enter Secondaries Service Consult">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Mock Interview Edit</label>
                          		<input type="text" class="form-control" id="mie" name="mie" placeholder="Enter Mock Interview Edit">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">Mock Interview Consult</label>
                          		<input type="text" class="form-control" id="mic" name="mic" placeholder="Enter Mock Interview Consult">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">General Edit</label>
                          		<input type="text" class="form-control" id="ge" name="ge" placeholder="Enter General Edit">
                          	</div>
            		    </div>
            		    <div class="col-md-3">
            		        <div class="form-group">
                          		<label for="exampleInputEmail1">General Consult</label>
                          		<input type="text" class="form-control" id="gc" name="gc" placeholder="Enter General Consult">
                          	</div>
            		    </div>
            		</div>
                    
                </div>
              	 
              	<div class="box-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputPassword1">Package/Service Cover</label>
                        		<div class="input-group input-file attachfile" name="attachfile">
                        			<span class="input-group-btn">
                                		<button class="btn btn-default btn-choose" type="button">Choose</button>
                            		</span>
                            		<input type="text" class="form-control" placeholder='Choose a file...' />
                            		<span class="input-group-btn">
                               			 <button class="btn btn-warning btn-reset" type="button">Reset</button>
                            		</span>
                        		</div>
        	                </div>
                        </div>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <span id="previewImg"></span>
                        </div>
                    </div>
                </div>
                
              	<div class="box-footer">
                	<button type="submit" class="btn btn-primary">Add Package/Service</button>
              	</div>
                <?php echo form_close(); ?>
          	</div>
      	</div>
  	</div>
</section>	
<?php echo Modules::run('Footer/Footer/index');?>
<script>
function bs_input_file() {
	$(".input-file").before(
		function() {
			if ( ! $(this).prev().hasClass('input-ghost') ) {
				var element = $("<input type='file' name='attachfile' class='input-ghost attachfile' style='visibility:hidden; height:0'>");
				element.attr("name",$(this).attr("name"));
				element.change(function(){
					element.next(element).find('input').val((element.val()).split('\\').pop());
				});
				$(this).find("button.btn-choose").click(function(){
					element.click();
				});
				$(this).find("button.btn-reset").click(function(){
					element.val(null);
					$(this).parents(".input-file").find('input').val('');
					$('#previewImg').html('');
				});
				$(this).find('input').css("cursor","pointer");
				$(this).find('input').mousedown(function() {
					$(this).parents('.input-file').prev().click();
					return false;
				});
				return element;
			}
		}
	);
}
$(function() {
	bs_input_file();
});
</script>
<script type="text/javascript">
$(document).ready(function(){
    $(".attachfile").change(function(){  
        readURL(this);  
    });
});

function readURL(input) {
if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(input.files[0]);
    reader.onload = function (e) {  
        $("#previewImg").html("<img class='img-thumbnail' src='" + e.target.result +"' width='200px'>");
      }
       reader.readAsDataURL(input.files[0]);
    }
}
$(document).ready(function(){
    $('#package-form').validate({
        rules:{
            company:{ required:true },
            name:{ required:true },
            price:{ required:true },
            attachfile:{ required:true }
        },
        messages:{
            category:{ required:'PLEASE SELECT COMPANY NAME.' },
            name:{ required:'PLEASE ENTER PAKAGE/SERVICE NAME.' },
            price:{ required:'PLEASE ENTER PACKAGE/SERVICE PRICE.' },
            attachfile:{ required:'PLEASE SELECT PAKAGE/SERVICE COVER IMAGE.' }
        }
    });
});

$('.toggle #checkbox').on('click',function(){
    if($(this).hasClass('on')) {
        $(this).removeClass('on').addClass('off'); 
        $(".bundled").slideUp({"display": 'none'});
        $('#isbundled').val('0');
        $(".bdlcount").slideDown({"display": 'block'});
        $('#edit').val('0');
        $('#consult').val('0');
    } else {
        $(this).removeClass('off').addClass('on');
        $(".bundled").slideDown({"display": 'block'});
        $('#isbundled').val('1');
        $(".bdlcount").slideUp({"display": 'none'});
        $('#edit').val('0');
        $('#consult').val('0');
    }
})
</script>


 