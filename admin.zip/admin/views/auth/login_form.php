<?php
$login = array(
	'name'	=> 'login',
	'id'	=> 'login',
	'value' => set_value('login'),
	'maxlength'	=> 80,
	'size'	=> 30,
	'placeholder'=>'E-Mail',
	'class'=>'form-control'
);
if ($login_by_username AND $login_by_email) {
	$login_label = 'Email or login';
} else if ($login_by_username) {
	$login_label = 'Login';
} else {
	$login_label = 'Email';
}
$password = array(
	'name'	=> 'password',
	'id'	=> 'password',
	'size'	=> 30,
	'placeholder'=>'Password',
	'class'=>'form-control'
);
$remember = array(
	'name'	=> 'remember',
	'id'	=> 'remember',
	'value'	=> 1,
	'checked'	=> set_value('remember'),
	'style' => 'margin:0;padding:0;display:none',
);
$captcha = array(
	'name'	=> 'captcha',
	'id'	=> 'captcha',
	'maxlength'	=> 8,
	'class'=>'form-control',
	'placeholder'=>'Confirmation Code',
	'style' => 'margin-top:10px',
);

$captcha_content = '';
if ($show_captcha) {
	if ($use_recaptcha) {
		$captcha_content = '
		<div id="account-signup-divider" class="shared-divider">
			<div class="shared-divider-label">
				<span>Confirmation Code</span>
			</div>
		</div>

		<div id="recaptcha_image"></div>
		<a href="javascript:Recaptcha.reload()">Get another CAPTCHA</a>
		<div class="recaptcha_only_if_image"><a href="javascript:Recaptcha.switch_type(\'audio\')">Get an audio CAPTCHA</a></div>
		<div class="recaptcha_only_if_audio"><a href="javascript:Recaptcha.switch_type(\'image\')">Get an image CAPTCHA</a></div>

		<div class="recaptcha_only_if_image">Enter the words above</div>
		<div class="recaptcha_only_if_audio">Enter the numbers you hear</div>
		<input type="text" id="recaptcha_response_field form-control" name="recaptcha_response_field" />

		<div id="account-signup-divider" class="shared-divider"></div>
		';

		$captcha_content .= $recaptcha_html;
	} else {
		$captcha_content = '
		<div id="account-signup-divider" class="shared-divider">
			<div class="shared-divider-label">
				<span>Confirmation Code</span>
			</div>
		</div>

		<p>Enter the code exactly as it appears:</p>
		'.$captcha_html.'
		<p>'.form_input($captcha).'</p>

		<div id="account-signup-divider" class="shared-divider"></div>
		';
	}
}

$submit = array(
    'class' => 'btn btn-primary btn-block btn-flat'
);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>White Coat Strategists</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/ionicons.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/blue.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/custom.css">

    <style>
         
        .checkbox input:checked + label { margin-left: 0px; }
        .checkbox label { width:90px; }
        .checkbox { margin-top:0px; }
        .form-group img { width:100%;}
        .error {
            font-size: 12px;
            letter-spacing: 0px;
            text-transform: uppercase; }
    </style>
    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <?php if($web->weblogo !="") {?>
                <a href="javascript:void(0)"><img src="<?=getuploadpath().'upload/web/'.$web->weblogo?>"></a>
            <?php } else { ?>
                <a href="javascript:void(0)"><b>WHITE COAT</b> STRATEGISTS</a>
            <?php } ?>
        </div>
        <div class="login-box-body">
            <p class="login-box-msg">SIGN IN TO ADMINISTRATION</p>
            <?php echo form_open($this->uri->uri_string()); ?>
            <div class="form-group has-feedback">
                <?php echo form_input($login); ?>
                <span class="fa fa-envelope form-control-feedback"></span>
                <span class="error"><?php echo form_error($login['name']); ?><?php echo isset($errors[$login['name']])?$errors[$login['name']]:''; ?></span>
            </div>
            <div class="form-group has-feedback">
                <?php echo form_password($password); ?>
                <span class="fa fa-unlock-alt form-control-feedback"></span>
                <span class="error"><?php echo form_error($password['name']); ?><?php echo isset($errors[$password['name']])?$errors[$password['name']]:''; ?></span>
            </div>
            <div class="form-group has-feedback">
                <?php echo $captcha_content; ?>	 
            </div>
            
            <div class="row">
                <div class="col-xs-8">
                    <div class="checkbox icheck">
                        <?php echo form_checkbox($remember); ?>
            			<?php echo form_label('Remember me', $remember['id']); ?>
                    </div>
                </div>
            
                <div class="col-xs-4">
                    <?php echo form_submit('submit', 'Let me in',$submit); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-6">
                    <div class="checkbox icheck">
                        <!--<?php if ($this->config->item('allow_registration', 'tank_auth')) echo anchor('/auth/register/', 'Register ?'); ?>-->
                        <a href="<?php echo base_url('auth/forgot_password/') ?>">Forgot password ?</a> 
                    </div>
                </div>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/bootstrap.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/icheck.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.validate.min.js"></script>
     
</body>
</html>
 
 

 
 