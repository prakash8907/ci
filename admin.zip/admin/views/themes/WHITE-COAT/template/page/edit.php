<?php echo Modules::run('Header/Header/index');
if($page->Banner !=""){
    $cover = getuploadpath().'upload/page/'.$page->Banner;
} else {
    $cover = base_url('admin/views/themes/default/assets/').'img/no-image-available.png';
}
?>
<section class="content-header">
  <h1> Pages </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('page')?>">Pages</a></li>
        <li class="active">Update</li>
  	</ol>
</section>
<section class="content">
  	<div class="row">
     	<div class="col-xs-12">
     	    <?php echo Modules::run('messages/message/index'); ?>
          	 <div class="box box-primary">
	            <div class="box-header with-border">
	              <h3 class="box-title">Update Content of Pages</h3>
	            </div>
                <?php 
                echo form_open_multipart('page/update',array('class'=>'page-form','id'=>'page-form'));
                ?>
             	<div class="box-body">
                	<div class="form-group">
                  		<label for="exampleInputEmail1">Title</label>
                  		<input type="hidden" class="form-control" name="id" value="<?php echo $page->Id?>">
                  		<input type="text" class="form-control" id="page" name="page" placeholder="Enter Page Name" value="<?php echo $page->Page?>" readonly>
            		</div>
            		<div class="form-group">
                  		<label for="exampleInputEmail1">Title</label>
                  		<input type="text" class="form-control" id="title" name="title" placeholder="Enter Page Title" value="<?php echo $page->Title?>">
            		</div>
                	<div class="form-group">
                  		<label for="exampleInputPassword1">Content</label>
      		            <textarea class="textarea" id="editor1" name="editor1" placeholder="Page Content" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $page->Description?></textarea>
                	</div>
              	</div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputPassword1">Page Banner</label>
                        		<div class="input-group input-file attachfile" name="attachfile">
                        			<span class="input-group-btn">
                                		<button class="btn btn-default btn-choose" type="button">Choose</button>
                            		</span>
                            		<input type="text" class="form-control" name="oldBanner" placeholder='Choose a file...' value="<?php echo $page->Banner; ?>" />
                            		<span class="input-group-btn">
                               			 <button class="btn btn-warning btn-reset" type="button">Reset</button>
                            		</span>
                        		</div>
        	                </div>
                        </div>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <span id="previewImg"><img src="<?php echo $cover ?>" style="width:200px"></span>
                        </div>
                    </div>
                </div>
              	<div class="box-footer">
                	<button type="submit" class="btn btn-primary">Update Content</button>
              	</div>
                <?php echo form_close(); ?>
          	</div>
      	</div>
  	</div>
</section>	
<?php echo Modules::run('Footer/Footer/index');?>
<script>
$(document).ready(function(){
    $('#page-form').validate({
        rules:{
            title:{ required:true }
        },
        messages:{
            title:{ required:'PLEASE ENTER PAGE TITLE.' }
        }
    });
});
</script>
<script>
function bs_input_file() {
	$(".input-file").before(
		function() {
			if ( ! $(this).prev().hasClass('input-ghost') ) {
				var element = $("<input type='file' name='attachfile' class='input-ghost attachfile' style='visibility:hidden; height:0'>");
				element.attr("name",$(this).attr("name"));
				element.change(function(){
					element.next(element).find('input').val((element.val()).split('\\').pop());
				});
				$(this).find("button.btn-choose").click(function(){
					element.click();
				});
				$(this).find("button.btn-reset").click(function(){
					element.val(null);
					$(this).parents(".input-file").find('input').val('');
					$('#previewImg').html('');
				});
				$(this).find('input').css("cursor","pointer");
				$(this).find('input').mousedown(function() {
					$(this).parents('.input-file').prev().click();
					return false;
				});
				return element;
			}
		}
	);
}
$(function() {
	bs_input_file();
});

$(document).ready(function(){
    $(".attachfile").change(function(){  
        readURL(this);  
    });
});

function readURL(input) {
if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(input.files[0]);
    reader.onload = function (e) {  
        $("#previewImg").html("<img class='img-thumbnail' src='" + e.target.result +"' width='200px'>");
      }
       reader.readAsDataURL(input.files[0]);
    }
}
</script>