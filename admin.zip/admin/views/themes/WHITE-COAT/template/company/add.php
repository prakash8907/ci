<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Company </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('company')?>">Company </a></li>
        <li class="active">Add</li>
  	</ol>
</section>
<section class="content">
  	<div class="row">
     	<div class="col-xs-12">
     	    <?php echo Modules::run('messages/message/index'); ?>
          	 <div class="box box-primary">
	            <div class="box-header with-border">
	              <h3 class="box-title">Add New Company</h3>
	            </div>
                <?php 
                echo form_open_multipart('company/insert',array('class'=>'company-form','id'=>'company-form'));
                ?>
             	<div class="box-body">
             	   
            		<div class="form-group">
                  		<label for="exampleInputEmail1">Company Name</label>
                  		<input type="text" class="form-control" id="name" name="name" placeholder="Enter Company Name">
                  	</div>
            		 
                	<div class="form-group">
                  		<label for="exampleInputPassword1">Company Description</label>
      		            <textarea class="textarea" id="editor1" name="editor1" placeholder="About Company" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                	</div>
                </div>
              	 
              	<div class="box-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputPassword1">Company Logo</label>
                        		<div class="input-group input-file attachfile" name="attachfile">
                        			<span class="input-group-btn">
                                		<button class="btn btn-default btn-choose" type="button">Choose</button>
                            		</span>
                            		<input type="text" class="form-control" placeholder='Choose a file...' />
                            		<span class="input-group-btn">
                               			 <button class="btn btn-warning btn-reset" type="button">Reset</button>
                            		</span>
                        		</div>
        	                </div>
                        </div>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <span id="previewImg"></span>
                        </div>
                    </div>
                </div>
                
              	<div class="box-footer">
                	<button type="submit" class="btn btn-primary">Add Company</button>
              	</div>
                <?php echo form_close(); ?>
          	</div>
      	</div>
  	</div>
</section>	
<?php echo Modules::run('Footer/Footer/index');?>
<script>
function bs_input_file() {
	$(".input-file").before(
		function() {
			if ( ! $(this).prev().hasClass('input-ghost') ) {
				var element = $("<input type='file' name='attachfile' class='input-ghost attachfile' style='visibility:hidden; height:0'>");
				element.attr("name",$(this).attr("name"));
				element.change(function(){
					element.next(element).find('input').val((element.val()).split('\\').pop());
				});
				$(this).find("button.btn-choose").click(function(){
					element.click();
				});
				$(this).find("button.btn-reset").click(function(){
					element.val(null);
					$(this).parents(".input-file").find('input').val('');
					$('#previewImg').html('');
				});
				$(this).find('input').css("cursor","pointer");
				$(this).find('input').mousedown(function() {
					$(this).parents('.input-file').prev().click();
					return false;
				});
				return element;
			}
		}
	);
}
$(function() {
	bs_input_file();
});
</script>
<script type="text/javascript">
$(document).ready(function(){
    $(".attachfile").change(function(){  
        readURL(this);  
    });
});

function readURL(input) {
if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(input.files[0]);
    reader.onload = function (e) {  
        $("#previewImg").html("<img class='img-thumbnail' src='" + e.target.result +"' width='200px'>");
      }
       reader.readAsDataURL(input.files[0]);
    }
}
$(document).ready(function(){
    $('#company-form').validate({
        rules:{
            name:{ required:true },
            attachfile:{ required:true }
        },
        messages:{
            name:{ required:'PLEASE ENTER COMPANY NAME.' },
            attachfile:{ required:'PLEASE SELECT COMPANY LOGO.' }
        }
    });
});
</script>


 