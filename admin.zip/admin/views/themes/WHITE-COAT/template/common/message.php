<?php if($this->session->flashdata('error')){ ?>
<div class="alert alert-danger fade in">
    <a href="#" class="close" data-dismiss="alert">&times;</a>
	
		<?php 
			echo $this->session->flashdata('error');
		 ?>
	
</div>
<?php } ?>
<?php if($this->session->flashdata('success')){ ?>
<div class="alert alert-success fade in">
    <a href="#" class="close" data-dismiss="alert">&times;</a>
	<i class="fa fa-check-circle"></i>
		<?php 
			echo $this->session->flashdata('success');
		 ?>
	
</div>
<div class="mt-xl"></div> 
<?php } ?>
<?php if($this->session->flashdata('warnings')){ ?>
	<div class="alert alert-warning fade in">
    <a href="#" class="close" data-dismiss="alert">&times;</a>
	
		<?php 
			echo $this->session->flashdata('warnings');
		 ?>
	
</div>
<div class="mt-xl"></div> 
<?php } ?>