<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Consultant extends MX_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->library('form_validation');
		$this->load->library('tank_auth');
		$this->load->model('Consultant_model','consultant');
	
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{   
	    $this->chk_login();
	    $data = array();
	    $id = $this->session->userdata('user_id');
	    $data['admin'] = $this->consultant->getAdmin($id,'users');
	    $data['consultant'] = $this->consultant->getconsultant();
	    $data['package'] = $this->consultant->getpackage();
	    $theme = $this->session->userdata('admin_theme');
	    if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/consultant/index.php'))
	    {
	        $this->load->view('themes/'.$theme. '/template/consultant/index',$data);
	    }
	    else
	    {
	        $this->load->view('themes/default/template/consultant/index',$data);
	    }
	}
	
	public function delete($id)
	{
	    $query = $this->consultant->delete($id);
		$this->session->set_flashdata('success','Consultant request delete Successfully');
		redirect('consultant');
	}
	
	public function activate($id)
	{
	    $consult = $this->consultant->getuser($id);
	    $email = $consult->email; 
	    $username = $consult->username; 
	    $pass = base64_decode($consult->pcnf);  
	    $data = array(
	        'activated' => '1',
	        'new_email_key' => NULL,
        );
        $this->consultant->activate($data,$id);
        $this->welcome($email,$username,$pass);
	}
	
	private function welcome($email,$username,$pass)
	{
	    $type = "consultant";
	    $email = $email;
	    $data['site_name'] = $this->config->item('website_name', 'tank_auth');
	    $data['username'] = $username;
	    $data['password'] = $pass;
	    $data['email'] = $email;
		$this->load->library('email');
		$this->email->from($this->config->item('webmaster_email', 'tank_auth'), $this->config->item('website_name', 'tank_auth'));
		$this->email->reply_to($this->config->item('webmaster_email', 'tank_auth'), $this->config->item('website_name', 'tank_auth'));
		$this->email->to($email);
		$this->email->subject(sprintf("Welcome to Join White Coat Strategists"));
		$this->email->message($this->load->view('email/'.$type.'-html', $data, TRUE));
		$this->email->set_alt_message($this->load->view('email/'.$type.'-txt', $data, TRUE));
		$this->email->send();
	}

    public function assign()
    {
        $consult = $this->input->post('consult_id');
        $pack = $this->input->post('package'); 
        $package = implode(',',$pack);
        $data = array('Package'=>$package);  
        $this->consultant->updatepkg($data,$consult);
        $pkId = explode(",",$package); 
        foreach($pkId as $pid){
        	$this->db->where('PkgId',$pid);
        	$pk = $this->db->get('tbl_package')->row();
            echo $pk->Name .'<br>';
        }
    }
    
    public function working()
    {
        $this->chk_login();
	    $data = array();
	    $id = $this->session->userdata('user_id');
	    $data['admin'] = $this->consultant->getAdmin($id,'users');
	    $data['consultant'] = $this->consultant->getconsultant();
	    $theme = $this->session->userdata('admin_theme');
	    if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/consultant/work.php'))
	    {
	        $this->load->view('themes/'.$theme. '/template/consultant/work',$data);
	    }
	    else
	    {
	        $this->load->view('themes/default/template/consultant/work',$data);
	    }
    }
    
    public function calculate()
    {
        $consult = post('consult');
        $from = date('Y-m-d H:i:s',strtotime(post('from')));  
        $to = date('Y-m-d H:i:s',strtotime(post('to'). ' +1 day'));    
        $data = $this->consultant->calculate($consult,$from,$to);
        $consulthour =  $this->consultant->calculatesingle($consult);   
        $sh_date = date('M d, Y',strtotime(post('from')));
        $sh_date1 = date('M d, Y',strtotime(post('to')));
        
        $minutes = 0; //declare minutes either it gives Notice: Undefined variable
     
        foreach ($data as $time) {
            list($hour, $minute) = explode(':', $time['Time']);
            $minutes += $hour * 60;
            $minutes += $minute;  
        }
    
        $hours = floor($minutes / 60);
        $minutes -= $hours * 60;
        $dddd = sprintf('%02d:%02d', $hours, $minutes);
        
        $t_hr = $consulthour->hours;
        
        
         
        // $total_hours = floor($t_hr/60);  
        // $total_minutes =  '00';
        // $total = sprintf('%02d:%02d', $total_hours, $total_minutes);
        
        // echo  var_dump($total-$dddd); exit;
        ?>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="info-box bg-red">
                <span class="info-box-icon"><i class="fa fa-clock-o"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Hours</span>
                    <span class="info-box-number"><?=$consulthour->hours." Hours"; ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: 70%"></div>
                    </div>
                    <span class="progress-description">
                        Available Working Hours
                    </span>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="info-box bg-yellow">
                <span class="info-box-icon"><i class="fa fa-clock-o"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Total Working Hours</span>
                    <span class="info-box-number"><?=sprintf('%02d:%02d', $hours, $minutes); ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: 70%"></div>
                    </div>
                    <span class="progress-description">
                        From : <?=$sh_date?> to : <?=$sh_date1?>
                    </span>
                </div>
            </div>
        </div>
        <?php
    }
}