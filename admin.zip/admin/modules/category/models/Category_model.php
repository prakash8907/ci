<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Category_model extends CI_model
{
    const PRI_INDEX = "CatId";
    const TABLE_NAME = "tbl_category";
    
    public function getAdmin($id,$table)
    {
        $this->db->where('id',$id);
        return $this->db->get($table)->row();
    }
    
    public function getAll()
    {
        $this->db->order_by(self::PRI_INDEX,'DESC');
        $this->db->where('Deleted','0');
        return $this->db->get(self::TABLE_NAME)->result_array();
    }
    
    public function insert($data)
    {
        $this->db->insert(self::TABLE_NAME,$data);
        return $this->db->insert_id();
    }
    
    public function update($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
        $this->db->update(self::TABLE_NAME,$data);
        return $this->db->affected_rows();
    }
    
    public function getSingle($id)
    {
        $this->db->where(self::PRI_INDEX,$id);
        return $this->db->get(self::TABLE_NAME)->row();
    }
    
    public function delete($catid,$data)
    {
        $this->db->where(self::PRI_INDEX,$catid);
        $this->db->update(self::TABLE_NAME,$data);
    }
}