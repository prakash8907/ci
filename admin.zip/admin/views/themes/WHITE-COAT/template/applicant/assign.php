<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Assign/Manage Package Count  
  </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('consultant')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('applicant')?>">New Consultant Request</a></li>
        <li class="active">Assign/Manage Package Count</li>
  	</ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-8">
            <?php echo Modules::run('messages/message/index'); ?>  
            <?php if(!empty($packdetail)){ foreach($packdetail as $pack):?>
            <ul class="timeline" id="activepack">
                <li class="time-label">
                    <span class="bg-red">
                        Active Package
                    </span>
                </li>
                <li> 
                    <i class="fa fa-cube bg-yellow"></i>
                     
                    <div class="timeline-item">
                        <h3 class="timeline-header"><a href="#"><?=$pack['Name']; ?></a> </h3>
                    </div><br> 
                    <div class="timeline-item packtimeline">
                        <?php if($pack['isbundled'] =='0') { ?>
                        <?php echo form_open('applicant/singlepack',array('class'=>'single-form'));?>
                        <input type="hidden" name="customer" value="<?=$pack['Customer'] ?>">
                        <input type="hidden" name="packid" value="<?=$pack['Package'] ?>">
                        <div class="box box-danger">
                            <div class="box-header with-border">
                                <h3 class="box-title">Edit and Consult Service</h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Edit - <?=$pack['edit']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Edit - <?=$pack['AS_Edit']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Edit" name="edit">
                                                    <option value="">Assign New Edit</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Consult - <?=$pack['consult']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Consult - <?=$pack['AS_Consult']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Consult" name="consult">
                                                    <option value="">Assign New Consult</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                        <div class="form-group pull-right">
                                            <button type="submit" class="btn btn-success">Assign Count</button>
                                        </div>
                                    </div>
                                </div>
                                 
                            </div>
                        </div>
                        <?php echo form_close() ?>
                        <?php } else { ?>
                        <?php echo form_open('applicant/bundled',array('class'=>'bundled-form'));?>
                        <input type="hidden" name="customer" value="<?=$pack['Customer'] ?>">
                        <input type="hidden" name="packid" value="<?=$pack['Package'] ?>">
                        <div class="box box-danger collapsed-box">
                            <div class="box-header with-border">
                                <h3 class="box-title">PS Service</h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Edit - <?=$pack['pse']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Edit - <?=$pack['AS_PSEdit']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Edit" name="psedit">
                                                    <option value="">Assign New Edit</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Consult - <?=$pack['psc']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Consult - <?=$pack['AS_PSConsult']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Consult" name="psconsult">
                                                    <option value="">Assign New Consult</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                 
                            </div>
                        </div> 
                        <!---->
                        <div class="box box-info collapsed-box space10">
                            <div class="box-header with-border">
                                <h3 class="box-title">Activities Service</h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Edit - <?=$pack['ase']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Edit - <?=$pack['AS_ACTEdit']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Edit" name="actedit">
                                                    <option value="">Assign New Edit</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Consult - <?=$pack['asc']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Consult - <?=$pack['AS_ACTConsult']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Consult" name="actconsult">
                                                    <option value="">Assign New Consult</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                 
                            </div>
                        </div> 
                        <!---->
                        <div class="box box-warning collapsed-box space10">
                            <div class="box-header with-border">
                                <h3 class="box-title">Secondaries Service</h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Edit - <?=$pack['sse']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Edit - <?=$pack['AS_SECEdit']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Edit" name="secedit">
                                                    <option value="">Assign New Edit</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Consult - <?=$pack['ssc']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Consult - <?=$pack['AS_SECConsult']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Consult" name="secconsult">
                                                    <option value="">Assign New Consult</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                 
                            </div>
                        </div> 
                        <!---->
                        <div class="box box-success collapsed-box space10">
                            <div class="box-header with-border">
                                <h3 class="box-title">Mock Interview Service</h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Count - <?php $t = $pack['mie'] + $pack['mic']; echo $t; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Consult - <?=$pack['AS_MOC']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Edit" name="mocedit">
                                                    <option value="">Assign New Edit</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                 
                            </div>
                        </div>
                        <!---->
                        <div class="box box-default collapsed-box space10">
                            <div class="box-header with-border">
                                <h3 class="box-title">General Consult Service</h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <p class="timeline-header">
                                            <a href="#" class="btn btn-xs bg-info">Total Consult - <?=$pack['gc']; ?></a> 
                                            <a href="#" class="btn btn-xs bg-info">New Assign Consult - <?=$pack['AS_GEN']; ?></a> 
                                            <div class="form-group">
                                                <select class="form-control" data-placeholder="Assign New Consult" name="genedit">
                                                    <option value="">Assign New Consult</option>
                                                    <?php for($i=1;$i<=5;$i++){ ?>
                                                        <option value="<?=$i?>"><?=$i?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                 
                            </div>
                        </div>
                        <div class="form-group space10">
                            <button type="submit" class="btn btn-success">Assign Count</button>
                        </div>
                        <?php echo form_close(); } ?>
                    </div>
                    
                </li>
            </ul> 
            <?php endforeach; } else { ?>
            <ul class="timeline" id="activepack">
                <li class="time-label">
                    <span class="bg-red">
                        Active Package
                    </span>
                </li>
                <li>
                    <i class="fa fa-cube bg-yellow"></i>
                    <div class="timeline-item">
                        <h3 class="timeline-header"><a href="#">There are no active package.</a> </h3>
                    </div>
                </li>
            </ul>
            <?php } ?>
         
             
                    
        </div>
    </div>
</section>
<?php echo Modules::run('Footer/Footer/index');?>