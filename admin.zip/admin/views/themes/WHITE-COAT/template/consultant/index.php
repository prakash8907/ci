<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> New Consultant Request  
  </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('consultant')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">New Consultant Request</li>
  	</ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
             <?php echo Modules::run('messages/message/index'); ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">New Request</h3>
                </div>
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SR#</th>
                                <th>Consultant Name </th>
                                <th>E-Mail</th>
                                <th>Assigned Package</th>
                                <th>Request Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $i='1';
                            foreach($consultant as $consult) :
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td> 
                                <td><?php echo $consult['username'];?></td>
                                <td><?php echo $consult['email'];?></td>
                                <td class='td_<?=$consult['id']?>'>
                                    <span class="col-md-8 spser_<?=$consult['id']?>">
                                    <?php if($consult['Package'] != NULL) {
                                        $pkId = explode(",",$consult['Package']); 
                                        foreach($pkId as $pid){
                                            $pk = $this->db->query("SELECT * FROM tbl_package WHERE PkgId = '$pid'")->row();
                                            echo $pk->Name .'<br>';
                                        }
                                    } 
                                    ?>
                                    <?php $lang = $consult['Package'];
                                            $l1 = explode(',',$lang); ?>
                                    <div class="form-group asdrop_<?=$consult['id']?>" style="display:none">
                                        <input type="hidden" name="consult_<?=$consult['id']?>" value="<?=$consult['id']?>">
                                        <select class="form-control pkg_<?=$consult['id']?>" multiple name="pkg_<?=$consult['id']?>">
                                            <?php foreach($package as $pkg):?>
                                                <option value="<?=$pkg['PkgId']?>" <?php echo in_array($pkg['PkgId'],$l1)?'selected':''?>><?=$pkg['Name']?></option>
                                            <?php endforeach;?>
                                        </select>
                                        <div class="space10">
                                            <button class="btn btn-block btn-warning btn-xs bt_<?=$consult['id']?>" onclick="submit('<?=$consult['id']?>')">SAVE</button>
                                        </div>
                                    </div>
                                    </span>
                                    <span class=col-md-4 pull-right">
                                    <a href="javascript:void(0)" class="btn btn-block btn-info btn-xs asbox_<?=$consult['id']?>" onclick="showdrop(<?=$consult['id']?>)">Assign</a></span>
                                </td>
                                <td><?php echo date('M d, Y',strtotime($consult['created']));?></td>
                                <td>
                                    <div class="btn-group-horizontal_<?=$consult['id']?>">
                                        <?php if($consult['activated'] == "0"){?>
                      					    <a href="<?php echo base_url('consultant/activate/').$consult['id']; ?>" data-id="<?=$consult['id']?>" class="label label-warning editcont activateconsult" >Activate</a>
                      					    <a href="<?php echo base_url('consultant/delete/').$consult['id']; ?>" class="label label-danger editcont" >DELETE</a>
                      					<?php } else { ?>
                      					    <a href="javascript:void(0)" class="label label-success editcont" >Activated</a>
                      					    <a href="<?php echo base_url('consultant/delete/').$consult['id']; ?>" class="label label-danger editcont" >DELETE</a>
                      					<?php } ?>
                    				</div>
                                </td> 
                            </tr>
                            <?php $i++; endforeach;  ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>SR#</th>
                                <th>Consultant Name </th>
                                <th>E-Mail</th>
                                <th>Assigned Package</th>
                                <th>Request Time</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo Modules::run('Footer/Footer/index');?>
<script>
$('.activateconsult').click(function(e){  
    e.preventDefault();
    url = $(this).attr('href');
    id = $(this).data('id');  
    swal({
        title: "Are you sure to activate consultant ?",
        text: "activate",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, activate it!",
        cancelButtonText: "No",
    }, function(isConfirm){
    
        if (isConfirm) {
            $.ajax({
                type:'POST',
                url:url,
                success:function(data)
                { 
                    $('.btn-group-horizontal_'+id).html('<a href="javascript:void(0)" class="label label-success editcont" >Activated</a>')
                }
            });
      	} 
    });
});


function showdrop(id) {
    $('.form-group').hide();
    $('.asbox_'+id).hide();
    $('.asdrop_'+id).show();
}

function submit(id)
{   
    var pkg = $('.pkg_'+id).val();  
    $('.bt_'+id).text('Wait...');
    $.ajax({
        type:'POST',
        url:'<?=base_url('consultant/assign')?>',
        data:{'consult_id':id,'package':pkg},
        success:function(data)
        {  
            $('.spser_'+id).html(data);
            $('.asbox_'+id).show();
            $('.asdrop_'+id).hide();
        }
    });
}
</script>
