<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Package_model extends CI_model
{
    const TABLE_NAME = 'tbl_package';
    const PRI_INDEX = 'PkgId';
    
    public function getAdmin($id,$table)
    {
        $this->db->where('id',$id);
        return $this->db->get($table)->row();
    }
    
    public function getAllOther($table)
    {
        $this->db->where('Deleted','0');
        return $this->db->get($table)->result_array();
    }
    
    public function getData($id)
    {
    	$this->db->where(self::PRI_INDEX,$id);
    	return $this->db->get(self::TABLE_NAME)->row();
    }

    public function insert($data)
    {
        if(!empty($data)){
            $this->db->insert(self::TABLE_NAME,$data);
            return $this->db->insert_id();
        }
    }
    
    public function getAll()
    {
        $this->db->where('tbl_package.Deleted','0');
        $this->db->select('tbl_package.*,tbl_company.Name as Companyname', FALSE);
        $this->db->join('tbl_company', 'tbl_company.CpyId = tbl_package.Company');
        $this->db->order_by('tbl_package.PkgId','DESC');
        return $this->db->get(self::TABLE_NAME)->result_array();
    }
    
    public function update($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
    	$this->db->update(self::TABLE_NAME,$data);
    	return $this->db->affected_rows();
    }
    
    public function delete($id,$data)
    {
        $this->db->where(self::PRI_INDEX,$id);
        $this->db->update(self::TABLE_NAME, $data);
    }
    
    
}	