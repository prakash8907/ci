<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Email
| -------------------------------------------------------------------------
| This file lets you define parameters for sending emails.
| Please see the user guide for info:
|
|	http://codeigniter.com/user_guide/libraries/email.html
|
*/
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'mail.whitecoatapp.com';
$config['smtp_port'] = 587;
$config['smtp_user'] = 'info@whitecoatapp.com';
$config['smtp_pass'] = 'dhrup@123';



/* End of file email.php */
/* Location: ./application/config/email.php */