<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Applicant Payment  
  </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('applicant')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Applicant Payment</li>
  	</ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
             <?php echo Modules::run('messages/message/index'); ?>
            <div class="box">
                <div class="box-body showconsult">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SR#</th>
                                <th>Applicant Name </th>
                                <th>E-Mail</th>
                                <th>Transaction Id</th>
                                <th>Amount</th>
                                <th>Package</th>
                                <th>Package Status</th>
                                <th>Pay Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php   
                            $i='1';
                            foreach($payment as $pay) :
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td> 
                                <td><?php echo ucwords($pay['username']);?></td>
                                <td><?php echo $pay['email'];?></td>
                                <td><?php echo $pay['Txn_id'];?></td>
                                <td><?php echo $pay['Amount'];?></td>
                                <td><?php echo $pay['Name'];?></td>
                                <td><?php if($pay['Pack_status'] == "1"){
                                    echo "<a href='javascript:void(0)' class='label label-danger'>Inactive</a>";
                                } else {
                                    echo "<a href='javascript:void(0)' class='label label-success'>Active</a>";
                                };?></td>
                                <td><?php echo date('M d, Y',strtotime($pay['Created_ON']));?></td>
                            </tr>
                            <?php $i++; endforeach;  ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>SR#</th>
                                <th>Applicant Name </th>
                                <th>E-Mail</th>
                                <th>Transaction Id</th>
                                <th>Amount</th>
                                <th>Package</th>
                                <th>Package Status</th>
                                <th>Pay Date</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!---->
 
<?php echo Modules::run('Footer/Footer/index');?>
 
 