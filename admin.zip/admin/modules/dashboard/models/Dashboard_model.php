<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard_model extends CI_model
{
    const PRI_INDEX = "id";
    const TABLE_NAME = "users";
    
    public function getAdmin($id)
    {
        $this->db->where(self::PRI_INDEX,$id);
        return $this->db->get(self::TABLE_NAME)->row();
    }
    
    public function countAll($table)
    {
        $this->db->where('Deleted','0');
        return $this->db->count_all_results($table);
    }
    
    public function getAll($table)
    {
        $this->db->order_by('Id','DESC');
        $this->db->where('Deleted','0');
        return $this->db->get($table)->result_array();
    }
}