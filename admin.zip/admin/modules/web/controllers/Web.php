<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Web extends MX_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->library('form_validation');
		$this->load->model('Web_model','web');
	
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{
	    $this->chk_login();
	    $data = array();
	    $id = $this->session->userdata('user_id');
	    $data['admin'] = $this->web->getAdmin($id,'users');
	    $data['web'] = $this->web->getdata();
	    $data['verify'] = $this->web->getdatasettings('setting');
	    $theme = $this->session->userdata('admin_theme');
	    if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/web/index.php'))
	    {
	        $this->load->view('themes/'.$theme. '/template/web/index',$data);
	    }
	    else
	    {
	        $this->load->view('themes/default/template/web/index',$data);
	    }
	}
	
	public function update()
	{
	    $this->form_validation->set_rules('name','Organization Name','required');
		if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('web/').post('webid');
        }
        else
        {
            $upload_path = $this->config->item('upload_path').'/web';
            if(!file_exists($upload_path))
        	{
        		mkdir($upload_path,0777,true);
        	}
            $config['upload_path']    =  $upload_path;
            $config['allowed_types']  = 'gif|jpg|png|jpeg|x-png';
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('weblogo')) {
        		$image = $this->upload->data();
        		$data['weblogo'] = $image['file_name'];
            }
            
            if ($this->upload->do_upload('weblogocolor')) {
        		$image = $this->upload->data();
        		$data['weblogocolor'] = $image['file_name'];
            }
            
            
            $adminId = post('webid');
            $data['name'] = ucwords(post('name'));
            $data['email'] = post('email');
            $data['contact'] = post('phone');
            $data['title'] = ucwords(post('title'));   
            $data['keyword'] = ucwords(post('keyword'));
            $data['desc'] = ucwords(post('desc'));
            $data['copyright'] = post('cpy');
            
            
            $sql = $this->web->update($adminId,$data);
            $this->session->set_flashdata('success','WebSettings Update Successfully.');
            redirect('web');
        }
	}
}