<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Consultant_model extends CI_model
{
    const TABLE_NAME = 'tbl_web';
    const PRI_INDEX = 'id';
    const TABLE_USER = 'tbl_register';
    
    public function getAdmin($id,$table)
    {
        $this->db->where(self::PRI_INDEX,$id);
        return $this->db->get($table)->row();
    }
    
    public function getconsultant()
    {
        $this->db->order_by('id','DESC');
        $this->db->where('type','Consultant');
        //$this->db->where('activated','1');
        return $this->db->get(self::TABLE_USER)->result_array();
    }
    
    public function delete($id)
    {
        $this->db->where('id',$id);
        $this->db->delete(self::TABLE_USER);
    }
  
    public function activate($data,$id)
    {
        $this->db->where('id',$id);
        $this->db->update(self::TABLE_USER,$data);
    }
    
    public function getuser($id)
    {
        $this->db->where('id',$id);
        return $this->db->get(self::TABLE_USER)->row();
    }
    
    public function getpackage()
    {
        $this->db->where('Deleted','0');
        return $this->db->get('tbl_package')->result_array();
    }
    
    public function updatepkg($data,$id)
    {
        $this->db->where('id',$id);
        return $this->db->update(self::TABLE_USER,$data);
    }
    
    public function calculate($consult,$from,$to)
    {
        $this->db->where('Deleted','0');
        $this->db->where('Consultant',$consult);
        $this->db->where('Date >=', $from);
        $this->db->where('Date <=', $to);
        return $this->db->get('tbl_time')->result_array();
    }
    public function calculatesingle($consult)
    {
        $this->db->where('id',$consult);
        return $this->db->get('tbl_register')->row();
    }
}	