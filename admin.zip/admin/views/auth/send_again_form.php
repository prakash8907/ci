<?php
$email = array(
	'name'	=> 'email',
	'id'	=> 'email',
	'value'	=> set_value('email'),
	'maxlength'	=> 80,
	'size'	=> 30,
	'placeholder'=>'E-Mail',
	'class'=>'form-control'
);
$submit = array(
    'class' => 'btn btn-primary btn-block btn-flat'
);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Activation</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/ionicons.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/blue.css">
    <link rel="stylesheet" href="<?=base_url('views/themes/WHITE-COAT/assets/') ?>css/custom.css">

    <style>
        .error {
            font-size: 12px;
            letter-spacing: 0px;
            text-transform: uppercase; }
    </style>
    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <a href="javascript:void(0)"><b>WHITE COAT</b> STRATEGISTS</a>
        </div>
        <div class="login-box-body">
            <p class="login-box-msg">SEND ACTIVATION E-MAIL ADMINISTRATION</p>
            <?php echo form_open($this->uri->uri_string()); ?>
            <div class="form-group has-feedback">
                <?php echo form_input($email); ?>
                <span class="fa fa-envelope form-control-feedback"></span>
                <span class="error"><?php echo form_error($email['name']); ?><?php echo isset($errors[$email['name']])?$errors[$email['name']]:''; ?></span>
            </div>
            <div class="form-group has-feedback">
                <?php echo form_submit('send', 'Send',$submit); ?>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/bootstrap.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/icheck.min.js"></script>
    <script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.validate.min.js"></script>
     
</body>
</html>