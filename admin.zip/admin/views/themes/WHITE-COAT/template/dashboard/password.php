<?php echo Modules::run('Header/Header/index');
$old_password = array(
	'name'	=> 'old_password',
	'id'	=> 'old_password',
	'value' => set_value('old_password'),
	'size' 	=> 30,
	'class' => 'form-control',
	'placeholder' => 'Old Password'
);
$new_password = array(
	'name'	=> 'new_password',
	'id'	=> 'new_password',
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
	'class' => 'form-control',
	'placeholder' => 'New Password'
);
$confirm_new_password = array(
	'name'	=> 'confirm_new_password',
	'id'	=> 'confirm_new_password',
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size' 	=> 30,
	'class' => 'form-control',
	'placeholder' => 'Confirm-Password'
);
$submit = array(
    'class' => 'btn btn-primary'
);
?>
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Change Password </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url('dashboard'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Change Password</li>
        </ol>
    </section>
 
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-6">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Change Password of Administration</h3>
                    </div>
                    <?php echo form_open('auth/change_password', array('id'=>'password-form')); ?>
                        <div class="box-body">
                            <?php echo Modules::run('messages/message/index'); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Old Password</label>
                                <?php echo form_password($old_password); ?>
                                <span class="error"><?php echo form_error($old_password['name']); ?><?php echo isset($errors[$old_password['name']])?$errors[$old_password['name']]:''; ?></span>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">New Password</label>
                                <?php echo form_password($new_password); ?>
                                <span class="error"><?php echo form_error($new_password['name']); ?><?php echo isset($errors[$new_password['name']])?$errors[$new_password['name']]:''; ?></span>
                            </div>
                            <div class="form-group">
                                <div id="strongy"></div>  
                            </div>
                            <div class="form-group">
                                <label for="exampleInputFile">Confirm Password</label>
                                <?php echo form_password($confirm_new_password); ?>
                                <span class="error"><?php echo form_error($confirm_new_password['name']); ?><?php echo isset($errors[$confirm_new_password['name']])?$errors[$confirm_new_password['name']]:''; ?></span>
                                <span id="msg"></span>
                            </div>
                        </div>
              
                        <div class="box-footer">
                            <?php echo form_submit('change', 'Change Password',$submit); ?>
                        </div>
                     <?php echo form_close() ?>
                </div>
            </div>
        </div>
    </section>
 
<?php echo Modules::run('Footer/Footer/index');?>
<script>
$(function() {
	$('#new_password').password({
		minLength:6,
		strengthIndicator:$('#strongy'),
	});
});

$(document).ready(function(){
    $('#password-form').validate({
        rules:{
            old_password:{ required:true },
            new_password:{ required:true },
            confirm_new_password:{ required:true }
        },
        messages:{
            old_password:{ required:'PLEASE ENTER OLD PASSWORD.' },
            new_password:{ required:'PLEASE ENTER NEW PASSWORD.' },
            confirm_new_password:{ required:'PLEASE ENTER CONFIRM PASSWORD.' }
        }
    });
});
$(document).ready(function(){
    $('#confirm_new_password').keyup(function(){  
        var x = $('#new_password').val();
        var y = $('#confirm_new_password').val();
        if( x != y)
        {
            $('#msg').html('PASSWORD & CON-PASSWORD NOT MATCH FOUND');
            $('#msg').css({'color':'rgb(255, 16, 2)','font-size':'11px','font-weight':'bold'});
            $('#confirm_new_password').focus();
        }
        else
        {
            $('#msg').html('PASSWORD & CON-PASSWORD MATCH FOUND.');
            $('#msg').css({'color':'Green','font-size':'11px','font-weight':'bold'});
        }
    });
});
</script>