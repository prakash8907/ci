<?php echo Modules::run('Header/Header/index');
if($admin->profile !=""){
    $profile = getuploadpath().'upload/admin/'.$admin->profile;
} else {
    $profile = base_url('views/themes/WHITE-COAT/assets/').'img/default_user.png';
}
?>
<section class="content-header">
    <h1>
        <?php echo ucwords($admin->username); ?> Profile
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url('dashboard') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo ucwords($admin->username); ?> profile</li>
    </ol>
</section>
 

<section class="content profiletab">
    <div class="row">
        <div class="col-md-3">
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <span id="previewImg">
                        <img class="profile-user-img img-responsive img-circle" src="<?php echo $profile; ?>" alt="admin">
                    </span>
                    <h3 class="profile-username text-center"><?php echo ucwords($admin->username) ?> </h3>
                    <p class="text-muted text-center"><?php echo $admin->email; ?></p>
                </div>
            </div>
          
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">About Me</h3>
                </div>
                <div class="box-body">
                    <strong><i class="fa fa-book margin-r-5"></i> Education</strong>
                        <p class="text-muted">
                        <?php echo $admin->edu; ?>
                        </p>
                    <hr>
                    <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
                    <p class="text-muted"><?php echo $admin->location; ?></p>
                    <hr>
                    <strong><i class="fa fa-file-text-o margin-r-5"></i> Bio</strong>
                    <p><?php echo $admin->bio; ?></p>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
            <?php echo Modules::run('messages/message/index'); ?>
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                     
                    <li  class="active"><a href="#settings" data-toggle="tab">Settings</a></li>
                </ul>
                
                <div class="tab-content">
                    <div class="tab-pane active" id="settings">
                         
                    <?php 
                        $attribute = array('class'=>'pro-form', 'id'=>'pro-form');
                        echo form_open_multipart('profile/update',$attribute);
                    ?>
                            <div class="row">
                                <div class="col-md-offset-1 col-md-5">
                                    <div class="form-group"> 
                                        <label for="exampleInputEmail1">Username</label>
                                        <input type="hidden" class="form-control" name="adminId" value="<?php echo $admin->id; ?>">
                                        <input type="text" class="form-control" id="fname" name="fname" placeholder="Enter first name" value="<?php echo $admin->username; ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-offset-1 col-md-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo $admin->email; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Phone Number</label>
                                        <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter phone" value="<?php echo $admin->phone; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Office Contact</label>
                                        <input type="text" class="form-control" id="office" name="office" placeholder="Enter office contact" value="<?php echo $admin->office; ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-offset-1 col-md-5">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Education</label>
                                        <input type="text" class="form-control" id="education" name="education" placeholder="Enter education" value="<?php echo $admin->edu; ?>">
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Location</label>
                                        <input type="text" class="form-control" id="location" name="location" placeholder="Enter location" value="<?php echo $admin->location; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-offset-1 col-md-10">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Bio</label>
                                        <textarea class="form-control" placeholder="Enter Bio" name="bio" style="resize:none;height:50px"><?php echo $admin->bio; ?></textarea>
                                    </div>
                                </div>
                            </div>
                            
                            
                            <div class="row">
                                <div class="col-md-offset-1 col-md-5">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Profile Image</label>
                                        <input type="file" name="profile" id="profile">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-offset-1 col-md-10">
                                    <button type="submit" class="btn btn-danger">Update Profile</button>
                                </div>
                            </div><br>
                    <?php echo form_close(); ?>  
                    </div>
                    
                </div>
             
            </div>
        </div>
        
    </div>
</section>
  
  
<?php echo Modules::run('Footer/Footer/index');?>

<script>
$(document).ready(function(){
    $('#pro-form').validate({
        rules:{
            phone:{ required:true, number:true },
            office:{ required:true, number:true },
            education:{ required:true },
            location:{ required:true },
            bio:{ required:true },
        },
        messages:{
            phone:{ required:'PLEASE ENTER CONTACT.', number:'PLEASE ENTER NUMBERS ONLY.' },
            office:{ required:'PLEASE ENTER OFFICE CONTACT.', number:'PLEASE ENTER NUMBERS ONLY.' },
            education:{ required:'PLEASE ENTER EDUCATION.' },
            location:{ required:'PLEASE ENTER LOCATION.' },
            bio:{ required:'PLEASE ENTER BIO.' }
        }
    });
});
</script>

<script type="text/javascript">
$("#profile").change(function(){  
    readURL(this);
});

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.readAsDataURL(input.files[0]);
        reader.onload = function (e) {  
            $("#previewImg").html("<img class='profile-user-img img-responsive img-circle' src='" + e.target.result +"' alt='admin'>");
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>