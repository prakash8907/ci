<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Terms </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Terms</li>
  	</ol>
</section>

<!-- Main content -->
<section class="content">
  	<div class="row">
     	<div class="col-xs-12">
     	    <?php echo Modules::run('messages/message/index'); ?>
          	<div class="box">
            	<div class="box-header">
              		<h3 class="box-title">Manage Content of Terms and Conditions </h3>
				</div>
            	<!-- /.box-header -->
            	<div class="box-body table-responsive no-padding">
              		<table class="table table-hover">
                		<tbody>
                			<tr>
                  				<th>ID</th>
                  				<th>Title</th>
                  				<th>Content</th>
                  				<th>Status</th>
                  				<th>Action</th>
                			</tr>
                			<?php 
                			if(!empty($terms)) :
                			foreach($terms as $trm):
                			?>
                			<tr>
                  				<td><?=$trm['Id'] ?></td>
                  				<td><?=$trm['Title'] ?></td>
                  				<td><?=substr($trm['Description'],0,100) ?></td>
                  				<td><span class="label label-<?php echo ($trm['Deleted'] == "0")?"success":"danger"?>"><?php echo ($trm['Deleted'] == "0")?"Active":"Inactive"?></span></td>
                  				<td>
                  					<div class="btn-group-horizontal">
                      					<a href="<?php echo base_url('terms/edit/').$trm['Id']; ?>" class="label label-warning editcont" data-toggle="modal" data-target="#myModal">EDIT</a>
                      					<a href="<?php echo base_url('terms/delete/').$trm['Id']; ?>" class="label label-danger editcont" data-toggle="modal" data-target="#myModal">DELETE</a>
                    				</div>
                  				</td>
                			</tr>
                		<?php endforeach; else : ?>
                		<tr class="text-center">
                		    <td colspan="5">No Data Available</td>
                		</tr>
                		<?php endif;?>
              			</tbody>
          			</table>
            	</div>
        	</div>
      	</div>
  	</div>
</section>	
<?php echo Modules::run('Footer/Footer/index');?>



