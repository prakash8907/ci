<?php if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class Header_model extends CI_Model {
    
    function getFullListFromDB($parent_id = '0') {
         
        $this->db->order_by('blog_cat.cat_id', 'asc');
       
        $this->db->where('blog_cat.par_cat_id',$parent_id);
       
        $result  = $this->db->get('blog_cat')->result_array();

        foreach($result as &$value) {

            $subresult = $this->getFullListFromDB($value["cat_id"]);

            if (count($subresult) > 0) {
                $value['children'] = $subresult;
            }
        }
        //unset($value);
       // echo $this->db->last_query();
        return $result;
    }
    
     function getContentVision($table)
	{
	    return $this->db->get($table)->result();
	}

}


