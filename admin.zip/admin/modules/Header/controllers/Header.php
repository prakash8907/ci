<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Header extends MX_Controller
{
	public function __construct()
	{
		parent :: __construct();
		$this->load->model('header_model','headerm');
	}

	public function index()
	{
		$data = array();
		$theme = $this->session->userdata('admin_theme');

		if(file_exists(APPPATH.'views/themes/'.$theme.'/template/common/header'))
		{
			$this->load->view('themes/'.$theme.'/template/common/header',$data);
		}
		else
		{
			$this->load->view('themes/WHITE-COAT/template/common/header',$data);
		}
	}
}