<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Applicant extends MX_Controller {
	public function __construct()
	{
		parent :: __construct();
		$this->load->library('form_validation');
		$this->load->library('tank_auth');
		$this->load->model('Applicant_model','applicant');
	
	}
	 
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{   
	    $this->chk_login();
	    $data = array();
	    $id = $this->session->userdata('user_id');
	    $data['admin'] = $this->applicant->getAdmin($id,'users');
	    $data['consultant'] = $this->applicant->getClient();
	    $theme = $this->session->userdata('admin_theme');
	    if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/applicant/index.php'))
	    {
	        $this->load->view('themes/'.$theme. '/template/applicant/index',$data);
	    }
	    else
	    {
	        $this->load->view('themes/default/template/applicant/index',$data);
	    }
	}
	
	public function assign($clientId)
	{   
	    $this->chk_login();
	    $data = array();
	    $id = $this->session->userdata('user_id');
	    $data['admin'] = $this->applicant->getAdmin($id,'users');
	    
	    $data['packdetail'] = $this->applicant->packdetail($clientId);
        
        $theme = $this->session->userdata('admin_theme');
	    if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/applicant/assign.php'))
	    {
	        $this->load->view('themes/'.$theme. '/template/applicant/assign',$data);
	    }
	    else
	    {
	        $this->load->view('themes/default/template/applicant/assign',$data);
	    }
	}
	
	public function delete($id)
	{
	    $query = $this->applicant->delete($id);
		$this->session->set_flashdata('success','Applicant delete Successfully');
		redirect('applicant');
	}
	
	public function bundled()
	{
	    $customer = post('customer');
        $pack = post('packid');
        $count = $this->applicant->countdetails($customer,$pack);  
	    $uspse = $count->PS_Edit;
	    $uspsc = $count->PS_Consult;
	    $usacte = $count->ACT_Edit;
	    $usactc = $count->ACT_Consult;
	    $ussece = $count->SEC_Edit;
	    $ussecc = $count->SEC_Consult;
	    $usmock = $count->MOCK_Consult;
	    $usgen = $count->GEN_Consult;
	     
	    
	    $psedit = post('psedit');
	    $psconsult = post('psconsult');
	    $actedit = post('actedit');
	    $actconsult = post('actconsult');
	    $secedit = post('secedit');
	    $secconsult = post('secconsult');
	    $mocedit = post('mocedit');
	    $genedit = post('genedit');
	    
	    
	    $data = array(
	        'PS_Edit'=>$uspse+$psedit,
            'PS_Consult' => $uspsc+$psconsult,
            'ACT_Edit' =>$usacte+$actedit,
            'ACT_Consult' =>$usactc+$actconsult,
            'SEC_Edit'=>$ussece+$secedit,
            'SEC_Consult'=>$ussecc+$secconsult,

            'MOCK_Consult'=>$usmock+$mocedit,
            'GEN_Consult'=>$usgen+$genedit,
            'AS_PSEdit' => $psedit,
            'AS_PSConsult' => $psconsult,
            'AS_ACTEdit' => $actedit,
            'AS_ACTConsult' => $actconsult,
            'AS_SECEdit' => $secedit,
            'AS_SECConsult' => $secconsult,
            'AS_MOC'=> $mocedit,
            'AS_GEN'=>$genedit
            
        );
        $this->applicant->assigncount($customer,$pack,$data);
        $this->session->set_flashdata('success','New count assign successfully.');
        redirect('applicant/assign/'.$customer);
	}
	
	public function singlepack()
	{
	    $customer = post('customer');
        $pack = post('packid');
	    $count = $this->applicant->countdetails($customer,$pack);  
	    $usedit = $count->Edit;
	    $usconsult = $count->Consult;
	    
	    $edit = post('edit');
	    $consult = post('consult');
	    
	    $data = array(
	        'Edit'=>$usedit+$edit,
	        'Consult'=>$usconsult+$consult,
	        'AS_Edit'=>$edit,
	        'AS_Consult'=>$consult
	    );  
	    $this->applicant->assigncount($customer,$pack,$data);
        $this->session->set_flashdata('success','New count assign successfully.');
        redirect('applicant/assign/'.$customer);
	    
	}
	
	function getclient()
	{
	    $userid = $_POST['client_id'];
	    $client = $this->applicant->getClientSingle($userid);
	    $image = substr($client->profile,'0','4');
	    $base = base_url();
	    $site = str_replace('admin/','',$base);
        switch ($image) {
            case "http":
                $profile = $client->profile;
                break;
            case "user":
                $profile = getuploadpath().'upload/user/'.$client->id.'/'.$client->profile;
                break;
            default:
                $profile = base_url('views/themes/WHITE-COAT/assets/').'img/default_user.png';
        } ?>
        <link href="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>css/style.css" rel="stylesheet">
        <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <img src="<?php echo $profile ?>" class="img-responsive center-block img-circle layer13" alt="<?=ucwords($client->username) ?>">
                    <h1><?=ucwords($client->username) ?></h1>
                    
                    <div class="panel-group" id="accordion">
                        <div class="panel white_box">
                            <div class="panel-heading">
                                <a data-toggle="collapse" href="#collapse0" data-parent="#accordion"><img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/add.png" class="add_img"></a>
                                <h4>About Applicant</h4>
                            </div>
                            <div id="collapse0" class="panel-collapse collapse">
                                <p><?=$client->about?></p>
                            </div>
                        </div>
                        <div class="panel white_box">
                            <div class="panel-heading"> 
                                <a data-toggle="collapse" href="#collapse1" data-parent="#accordion"><img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/add.png" class="add_img"></a>
                                <a><h4>Educational Details</h4></a>
                            </div>
                            <div id="collapse1" class="panel-collapse collapse">
                                <?php if($client->pg_inst !=""): ?> 
                                <div class="media">
                                    <div class="media-left"> 
                                        <img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/home.png" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h5>Post Graduate Institute Name : <?=$client->pg_inst?></h5>
                                        <h6><?=$client->pg_dgree?><br><span><?=$client->pg_start?>-<?=$client->pg_end?></span> </h6>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if($client->gra_inst !=""): ?> 
                                <div class="media">
                                    <div class="media-left">
                                        <img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/home.png" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h5>Graduate Institute Name : <?=$client->gra_inst?></h5>
                                        <h6><?=$client->gra_dgree?><br><span><?=$client->gra_start?>-<?=$client->gra_end?></span> </h6>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if($client->hs_inst !=""): ?> 
                                <div class="media">
                                    <div class="media-left">
                                        <img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/home.png" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h5>High School Institute Name : <?=$client->hs_inst?></h5>
                                        <h6><?=$client->hs_dgree?><br><span><?=$client->hs_start?>-<?=$client->hs_end?></span> </h6>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if($client->oth_inst !=""): ?>    
                                <div class="media">
                                    <div class="media-left">
                                        <img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/home.png" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h5>Any other Institute Name : <?=$client->oth_inst?></h5>
                                        <h6><?=$client->oth_dgree?><br><span><?=$client->oth_start ?>-<?=$client->oth_end ?></span> </h6>
                                    </div>
                                </div>
                                <?php endif; if($client->ov_gpa !=""):?>
                                <div class="media ocpabox">
                                    <div class="media-left">
                                        <img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/home.png" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h5>Overall GPA : </h5>
                                        <h6><?=$client->ov_gpa ?></h6>
                                    </div>
                                </div>
                                <?php endif; if($client->sc_gpa !=""):?>
                                <div class="media sgpabox">
                                    <div class="media-left">
                                        <img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/home.png" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h5>Science GPA :</h5>
                                        <h6><?=$client->sc_gpa ?></h6>
                                    </div>
                                </div>
                                <?php endif; if($client->mcat !=""):?>
                                <div class="media mcatbox">
                                    <div class="media-left">
                                        <img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/home.png" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h5>MCAT :</h5>
                                        <h6><?=$client->mcat ?></h6>
                                    </div>
                                </div>
                                <?php endif;?>
                            </div>
                        </div>
                        <div class="panel white_box">
                            <div class="panel-heading">
                                <a data-toggle="collapse" href="#collapse2" data-parent="#accordion"><img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/add.png"  class="add_img"></a>
                                <a><h4>Major activities</h4></a>
                            </div>
                            <div id="collapse2" class="panel-collapse collapse">
                                <p><?=$client->activity?></p>
                            </div>
                        </div>
                        <div class="panel white_box">
                            <div class="panel-heading">
                                <a data-toggle="collapse" href="#collapse3" data-parent="#accordion"><img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/add.png" class="add_img"></a>
                                <a><h4>Community service</h4></a>
                            </div>
                            <div id="collapse3" class="panel-collapse collapse">
                                <p><?=$client->community?></p>
                            </div>
                        </div>
                        <div class="panel white_box">
                            <div class="panel-heading">
                                <a data-toggle="collapse" href="#collapse4" data-parent="#accordion"><img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/add.png" class="add_img"></a>
                                <a><h4>Hobbies</h4></a>
                            </div>
                            <div id="collapse4" class="panel-collapse collapse">
                                <p><?=$client->hobbies?></p>
                            </div>
                        </div>
                        <div class="panel white_box">
                            <div class="panel-heading">
                                <a data-toggle="collapse" href="#collapse5" data-parent="#accordion"><img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/add.png" class="add_img"></a>
                                <a><h4>Clinical experience</h4></a>
                            </div>
                            <div id="collapse5" class="panel-collapse collapse">
                                <p><?=$client->clinical?></p>
                            </div>
                        </div>
                        <div class="panel white_box">
                            <div class="panel-heading">
                                <a data-toggle="collapse" href="#collapse6" data-parent="#accordion"><img src="<?php echo $site .'front/views/themes/WHITE-COAT/assets/' ?>img/add.png" class="add_img"></a>
                                <h4>Associate Consultant</h4>
                            </div>
                            <div id="collapse6" class="panel-collapse collapse">
                                <p><?php if($client->Package !=""){
                                    $p = $this->db->query("SELECT * FROM tbl_package WHERE PkgId =".$client->Package)->row(); 
                                    echo "Active Package Name - ".$p->Name."<br>";
                                    $allconsult = $this->db->query("SELECT * FROM tbl_meeting WHERE Status = '0' AND Client =".$client->id)->result_array();
                                    foreach($allconsult as $cns):
                                        $cId = $cns['Consultant'];
                                        $cname = $this->db->query("SELECT * FROM tbl_register WHERE id =".$cId)->row();  
                                        echo "Consultant Name - " .$cname->username."<br>";
                                    endforeach;
                                } else {
                                    echo "No active Package";
                                }?></p>
                            </div>
                        </div>
                        <!---->
                    </div> 
                </div>
            </div>
        <?php
	}

}