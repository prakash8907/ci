<?php echo Modules::run('Header/Header/index');?>
<section class="content-header">
  <h1> Blogs Category  </h1>
  	<ol class="breadcrumb">
        <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('category')?>">Blogs Category </a></li>
        <li class="active">Add</li>
  	</ol>
</section>
<section class="content">
  	<div class="row">
     	<div class="col-xs-12">
     	    <?php echo Modules::run('messages/message/index'); ?>
          	 <div class="box box-primary">
	            <div class="box-header with-border">
	              <h3 class="box-title">Add New Blogs Category</h3>
	            </div>
                <?php 
                echo form_open_multipart('category/insert',array('class'=>'category-form','id'=>'category-form'));
                ?>
             	<div class="box-body">
                	<div class="form-group">
                  		<label for="exampleInputEmail1">Category Title</label>
                  		<input type="text" class="form-control" id="title" name="title" placeholder="Enter Title" value="" autofocus>
            		</div>
                	<div class="form-group">
                  		<label for="exampleInputPassword1">Category Description</label>
      		            <textarea class="form-control" name="desc" placeholder="Category Description"></textarea>
                	</div>
              	</div>
                <div class="box-footer">
                	<button type="submit" class="btn btn-primary">Add Category</button>
              	</div>
                <?php echo form_close(); ?>
          	</div>
      	</div>
  	</div>
</section>	
<?php echo Modules::run('Footer/Footer/index');?>
<script>
$(document).ready(function(){
    $('#category-form').validate({
        rules:{
            title:{ required:true }
        },
        messages:{
            title:{ required:'PLEASE ENTER TITLE.' }
        }
    });
});
</script>

 