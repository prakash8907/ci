<?php

class Checkrights
{
    function index() {
        
        $CI =& get_instance();
        $is_login = $CI->session->userdata('is_admin');

        
    }
}

