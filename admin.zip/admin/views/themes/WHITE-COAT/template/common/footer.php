   </div>
  <!-- /.content-wrapper -->
<?php 
$WEB = $this->db->get('tbl_web')->result_array();
?>
<footer class="main-footer">
    <?php echo $WEB[0]['copyright']; ?> 
</footer>

<aside class="control-sidebar control-sidebar-dark">
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs"></ul>
    <div class="tab-content">
        <div class="tab-pane" id="control-sidebar-home-tab">
        </div>
    </div>
</aside>
    <div class="control-sidebar-bg"></div>
</div>
 

<!-- jQuery 3 -->
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/bootstrap.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/fastclick.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/adminlte.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.sparkline.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.slimscroll.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/Chart.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/dashboard2.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/demo.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.validate.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/sweet-alert.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.password.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jasny-bootstrap.min.js"></script>
<script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/jquery.dataTables.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/dataTables.bootstrap.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/bootstrap-datepicker.min.js"></script>
<script src="<?=base_url('views/themes/WHITE-COAT/assets/') ?>js/select2.full.min.js"></script>

<script>
  $(function () {
    CKEDITOR.replace('editor1'),
    CKEDITOR.replace('editor2')
  })

$(function () {
    $('.select2').select2()
})

$('#datepickerfrom').datepicker({
  autoclose: true,
  format: 'yyyy-mm-dd'
})
$('#datepickerto').datepicker({
  autoclose: true,
  format: 'yyyy-mm-dd'
})
</script>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<script>
$('.logout').click(function(e){  
    e.preventDefault();
    url =$(this).attr('href');
    swal({
        title: "Are you sure to logout ?",
        text: "Logout",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, Logout it!",
        cancelButtonText: "No",
    }, function(isConfirm){
    
        if (isConfirm) {
            $.ajax({
                type:'POST',
                url:url,
                success:function()
                {
                    window.location.href = "<?php echo base_url('auth/login') ?>";
                }
            });
      	} 
    });
});
</script>

</body>
</html>

 