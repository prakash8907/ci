<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Page extends MX_Controller {
	public function __construct()
	{
	    parent :: __construct();
		$this->load->library('form_validation');
		$this->load->model('Page_model','page');   
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{
	    $this->chk_login();
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->page->getAdmin($id,'users');
        $data['page'] = $this->page->getAll();
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/page/index.php'))
		{
			$this->load->view('themes/'.$theme.'/template/page/index',$data);
		}
		else
		{
			$this->load->view('themes/default/template/page/index',$data);
		}
	}
	
	public function edit($pageid)
	{
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->page->getAdmin($id,'users');
		$data['page'] = $this->page->getData($pageid);
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/page/edit.php'))
		{
			$this->load->view('themes/'.$theme.'/template/page/edit',$data);
		}
		else
		{
			$this->load->view('themes/default/template/page/edit',$data);
		}
	}
	
	public function update()
	{
	    $this->form_validation->set_rules('title','Page Title','required');
		if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('page/edit/'.post('id'));
        }
        else
        {   
            $upload_path = $this->config->item('upload_path').'/page';
        	if(!file_exists($upload_path))
        	{
        		mkdir($upload_path,0777,true);
        	}
        	$config['upload_path']    =  $upload_path;
            $config['allowed_types']  = 'gif|jpg|png|jpeg|x-png|pdf|doc|docx';
			$this->load->library('upload', $config);
            if ($this->upload->do_upload('attachfile')) {
        		$image = $this->upload->data();
        		$data['Banner'] = $image['file_name'];
            } else {
                $data['Banner'] = post('oldBanner');
            }
            
            
            $id = post('id');
            $data['Page'] = strtoupper(post('page'));
            $data['Title'] = ucwords(post('title'));
            $data['Description'] = post('editor1');
            $data['ModifiedOn'] = date('Y-m-d h:i:s');
            $data['ModifiedBy'] = $this->session->userdata('user_id');
            
            $sql = $this->page->update($id,$data);
            $this->session->set_flashdata('success','Page Content Update Successfully.');
            redirect('page');
        }
	}
	
	public function delete($id)
	{
	    $data = array();
	    $data['Deleted'] = '1';
		$query = $this->page->delete($id,$data);
		$this->session->set_flashdata('success','Page Content delete Successfully');
		redirect('page');
	}
}