<?php echo Modules::run('Header/Header/index');?>
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Dashboard </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url('dashboard'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
 
    <!-- Main content -->
   
 
<?php echo Modules::run('Footer/Footer/index');?>