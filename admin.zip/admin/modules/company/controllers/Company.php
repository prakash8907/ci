<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Company extends MX_Controller {
	public function __construct()
	{
	    parent :: __construct();
		$this->load->library('form_validation');
		$this->load->model('Company_model','company');   
	}
	
	private function chk_login(){
		if($this->session->userdata('user_id')==''){
			redirect("auth/login");
			return false;
		}
	}
	
	public function index()
	{
	    $this->chk_login();
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->company->getAdmin($id,'users');
		$data['company'] = $this->company->getAll();
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/company/index.php'))
		{
			$this->load->view('themes/'.$theme.'/template/company/index',$data);
		}
		else
		{
			$this->load->view('themes/default/template/company/index',$data);
		}
	}
	
	public function add()
	{
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->company->getAdmin($id,'users');
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/company/add.php'))
		{
			$this->load->view('themes/'.$theme.'/template/company/add',$data);
		}
		else
		{
			$this->load->view('themes/default/template/company/add',$data);
		}
	}
	
	public function insert()
	{
	    $this->form_validation->set_rules('name','Company name','required');
		if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('company/add');
        }
        else
        {
            $upload_path = $this->config->item('upload_path').'/company';
        	if(!file_exists($upload_path))
        	{
        		mkdir($upload_path,0777,true);
        	}
        	$config['upload_path']    =  $upload_path;
            $config['allowed_types']  = 'gif|jpg|png|jpeg|x-png|pdf|doc|docx';
			$this->load->library('upload', $config);
            
            if ($this->upload->do_upload('attachfile')) {
        		$image = $this->upload->data();
        		$data['Logo'] = $image['file_name'];
            } 
            
            $data['Name'] = ucwords(post('name'));
            $data['Description'] = post('editor1');
            $sql = $this->company->insert($data);
            $this->session->set_flashdata('success','Company Added Successfully.');
            redirect('company');
        }
	}
	
	public function edit($cpyid)
	{
		$data = array();
		$id = $this->session->userdata('user_id');
        $data['admin'] = $this->company->getAdmin($id,'users');
		$data['company'] = $this->company->getData($cpyid);
		$theme = $this->session->userdata('admin_theme');
		if(file_exists(APPPATH. 'views/themes/'.$theme. '/template/company/edit.php'))
		{
			$this->load->view('themes/'.$theme.'/template/company/edit',$data);
		}
		else
		{
			$this->load->view('themes/default/template/company/edit',$data);
		}
	}
	
	public function update()
	{
	    $this->form_validation->set_rules('name','Company name','required');
		if ($this->form_validation->run() == FALSE){
	        $this->session->set_flashdata('error', validation_errors());
            redirect('company/edit/'.post('id'));
        }
        else
        {
            $upload_path = $this->config->item('upload_path').'/company';
        	if(!file_exists($upload_path))
        	{
        		mkdir($upload_path,0777,true);
        	}
        	$config['upload_path']    =  $upload_path;
            $config['allowed_types']  = 'gif|jpg|png|jpeg|x-png|pdf|doc|docx';
			$this->load->library('upload', $config);
            if ($this->upload->do_upload('attachfile')) {
        		$image = $this->upload->data();
        		$data['Logo'] = $image['file_name'];
            } else {
                $data['Logo'] = post('oldLogo');
            }
            
            $id = post('id');
            $data['Name'] = ucwords(post('name'));
            $data['Description'] = post('editor1');
            $data['ModifiedOn'] = date('Y-m-d h:i:s');
            $data['ModifiedBy'] = $this->session->userdata('user_id');
            
            $sql = $this->company->update($id,$data);
            $this->session->set_flashdata('success','Company details Update Successfully.');
            redirect('company');
        }
	}
	
	public function delete($id)
	{
	    $data = array();
	    $data['Deleted'] = '1';
		$query = $this->company->delete($id,$data);
		$this->session->set_flashdata('success','Company details delete Successfully');
		redirect('company');
	}
}